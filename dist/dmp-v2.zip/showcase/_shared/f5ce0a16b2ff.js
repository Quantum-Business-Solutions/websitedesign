
(function(){
'use strict';
var root=document.documentElement;
if(root.getAttribute('data-dir')!=='showcase')return;
var reduce=window.matchMedia('(prefers-reduced-motion: reduce)');
function $(s,c){return (c||document).querySelector(s)}
function $$(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))}

/* heartbeat: count check-ins, pause with the tab */
var live=$('.pn-beat-live'),count=$('[data-pn-beat]'),n=1;
if(live&&count){live.addEventListener('animationiteration',function(){n+=1;count.textContent='CHECK-IN '+('000'+n).slice(-4)})}
document.addEventListener('visibilitychange',function(){root.classList.toggle('pn-hidden',document.hidden)});

/* zone bar on inner pages: bring the current system into view on phones */
var cur=$('.pn-zb:not(.pn-zb-home) a.is-on');
if(cur&&cur.scrollIntoView&&window.matchMedia('(max-width:767px)').matches){var zb=cur.closest('.pn-zb');zb.scrollLeft=Math.max(0,cur.offsetLeft-16)}

var kp=$('#pn-kp');
if(!kp)return;

/* ---------- clock ---------- */
function p2(v){return (v<10?'0':'')+v}
function stamp(){var d=new Date();return p2(d.getHours())+':'+p2(d.getMinutes())+':'+p2(d.getSeconds())}
function tick(){var d=new Date(),h=d.getHours(),m=d.getMinutes(),days=['SUN','MON','TUE','WED','THU','FRI','SAT'];
  var a=$('[data-pn-day]'),b=$('[data-pn-time]');if(a)a.textContent=days[d.getDay()];if(b)b.textContent=((h%12)||12)+':'+p2(m)+(h<12?' AM':' PM')}
tick();var clock=setInterval(tick,20000);

/* ---------- sound: off by default, WebAudio, no assets ---------- */
var ctx=null,soundOn=false,snd=$('[data-pn-sound]');
function beep(freq,at,dur,vol,type){
  if(!soundOn||!ctx||reduce.matches)return;
  var t=ctx.currentTime+(at||0),o=ctx.createOscillator(),g=ctx.createGain();
  o.type=type||'sine';o.frequency.value=freq;
  g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(vol||0.06,t+0.012);g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
  o.connect(g);g.connect(ctx.destination);o.start(t);o.stop(t+dur+0.02);
}
if(snd){snd.addEventListener('click',function(){
  soundOn=!soundOn;
  if(soundOn&&!ctx){var AC=window.AudioContext||window.webkitAudioContext;if(AC){try{ctx=new AC()}catch(e){ctx=null}}}
  if(ctx&&ctx.state==='suspended'){ctx.resume()}
  snd.setAttribute('aria-pressed',String(soundOn));
  var t=$('[data-pn-sndtxt]',snd);if(t)t.textContent=soundOn?'Sound on':'Sound off';
  beep(1320,0,0.09);
})}

/* ---------- arm / disarm ---------- */
var EXIT=3,state='armed',timer=null,left=0;
var toggles=$$('[data-pn-toggle]'),shield=$('.pn-kp-shield'),labels=$$('[data-pn-label]'),armtxt=$$('[data-pn-armtxt]');
var headline=$('[data-pn-headline]'),status=$('[data-pn-status]'),zst=$$('[data-pn-zst]'),hint=$('[data-pn-hint]'),logline=$('[data-pn-logline]'),invite=$('[data-pn-invite]');
var list=$('[data-pn-events-list]'),events=[];
function log(msg){
  events.unshift([stamp(),msg]);events=events.slice(0,6);
  if(logline)logline.textContent=events[0][0]+'  '+msg;
  if(list){list.textContent='';events.forEach(function(e){var li=document.createElement('li'),b=document.createElement('b'),s=document.createElement('span');b.textContent=e[0];s.textContent=e[1];li.appendChild(b);li.appendChild(s);list.appendChild(li)})}
}
function say(t){if(hint)hint.textContent=t}
function paint(s){
  state=s;root.setAttribute('data-pn',s);
  var word=s==='armed'?'ARMED':s==='arming'?'ARMING '+left:'DISARMED';
  labels.forEach(function(el){el.textContent=word});
  if(headline)headline.textContent=s==='armed'?'Armed.':s==='arming'?'Arming.':'Disarmed.';
  if(shield){shield.setAttribute('aria-pressed',String(s==='armed'));shield.setAttribute('aria-label',s==='armed'?'Site armed. Press to disarm':s==='arming'?'Arming. Press to cancel':'Site disarmed. Press to arm')}
  armtxt.forEach(function(b){b.textContent=s==='armed'?'Disarm':s==='arming'?'Cancel':'Arm all'});
  if(status)status.textContent=s==='armed'?'Secure':s==='arming'?'Arming':'Ready';
  zst.forEach(function(el){el.textContent=s==='armed'?'Secure':s==='arming'?'Arming':'Bypassed'});
  if(invite)invite.textContent=s==='armed'?'Disarm it, then arm it again.':s==='arming'?'Exit delay running.':'Arm it.';
}
function sweep(){
  if(reduce.matches)return;
  var el=document.createElement('i');el.className='pn-sweep';el.setAttribute('aria-hidden','true');document.body.appendChild(el);
  el.addEventListener('animationend',function(){el.remove()});
}
function thunk(){if(reduce.matches)return;root.classList.remove('pn-thunk');void kp.offsetWidth;root.classList.add('pn-thunk');setTimeout(function(){root.classList.remove('pn-thunk')},600)}
function finishArm(){
  if(timer){clearInterval(timer);timer=null}left=0;
  paint('armed');log('All zones armed. Supervised.');say('Site armed. Six zones supervised.');
  beep(880,0,0.1);beep(1320,0.11,0.22,0.07);sweep();thunk();
}
function arm(){
  if(reduce.matches){finishArm();return}
  left=EXIT;root.style.setProperty('--pn-exit',EXIT+'s');
  paint('arming');log('Exit delay. Arming all zones.');say('Arming in '+left+'. Press again to cancel.');beep(990,0,0.06,0.04,'square');
  timer=setInterval(function(){
    left-=1;
    if(left<=0){finishArm()}
    else{labels.forEach(function(el){el.textContent='ARMING '+left});say('Arming in '+left+'. Press again to cancel.');beep(990,0,0.06,0.04,'square')}
  },1000);
}
function disarm(){
  var was=state;
  if(timer){clearInterval(timer);timer=null}left=0;
  paint('disarmed');log(was==='arming'?'Arming cancelled.':'System disarmed.');say(was==='arming'?'Arming cancelled. Site disarmed.':'Site disarmed. Press the shield to arm.');
  beep(1320,0,0.08);beep(880,0.1,0.16);if(was==='armed')sweep();
}
function toggle(){if(state==='disarmed')arm();else disarm()}
toggles.forEach(function(b){b.addEventListener('click',toggle)});
log('System armed');

/* events log on the keypad screen */
var evBox=$('#pn-events'),evOpen=$('[data-pn-events-open]'),evClose=$('[data-pn-events-close]');
function showEvents(open){
  if(!evBox)return;evBox.hidden=!open;if(evOpen)evOpen.setAttribute('aria-expanded',String(open));
  if(open){if(evClose)evClose.focus()}else if(evOpen){evOpen.focus()}
  beep(1900,0,0.03,0.02,'square');
}
if(evOpen)evOpen.addEventListener('click',function(){showEvents(evBox.hidden)});
if(evClose)evClose.addEventListener('click',function(){showEvents(false)});
if(evBox)evBox.addEventListener('keydown',function(e){if(e.key==='Escape'){showEvents(false)}});

/* phones: the on-screen menu is too small to tap, the zone bar carries the same six links */
var small=window.matchMedia('(max-width:599px)'),menu=$('.pn-kp-menu');
function inert(){if(!menu)return;if(small.matches){menu.setAttribute('inert','');menu.setAttribute('aria-hidden','true')}else{menu.removeAttribute('inert');menu.removeAttribute('aria-hidden')}}
inert();if(small.addEventListener)small.addEventListener('change',inert);else if(small.addListener)small.addListener(inert);

/* ---------- zones light as their scene comes into view ---------- */
var links=$$('.pn-zb-home a[data-z]'),zones=$$('.pn-zone[data-zone]');
function setActive(k){
  links.forEach(function(a){var z=+a.getAttribute('data-z');a.classList.toggle('is-on',z===k);if(z===k)a.setAttribute('aria-current','true');else a.removeAttribute('aria-current')});
}
if('IntersectionObserver' in window){
  var vis={};
  var io=new IntersectionObserver(function(es){
    es.forEach(function(e){vis[e.target.getAttribute('data-zone')]=e.isIntersecting});
    var on=0;zones.forEach(function(s){if(vis[s.getAttribute('data-zone')])on=+s.getAttribute('data-zone')});setActive(on);
  },{rootMargin:'-42% 0px -56% 0px'});
  zones.forEach(function(s){io.observe(s)});
  var liveIO=new IntersectionObserver(function(es){es.forEach(function(e){e.target.classList.toggle('pn-live',e.isIntersecting)})},{rootMargin:'80px 0px'});
  $$('.pn-zone,.pn-hero').forEach(function(el){liveIO.observe(el)});
  var seen=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;e.target.classList.add('in','seen');seen.unobserve(e.target)})},{rootMargin:'0px 0px -10% 0px',threshold:0.1});
  $$('.pn-rv,.pn-z1').forEach(function(el){seen.observe(el)});
}else{$$('.pn-rv,.pn-z1').forEach(function(el){el.classList.add('in','seen')});$$('.pn-zone,.pn-hero').forEach(function(el){el.classList.add('pn-live')})}

/* plant feed: load and play only in view, never with reduced motion, pause when the tab is hidden */
var holder=$('[data-pn-video]'),vid=null;
function play(){if(vid&&!document.hidden){var q=vid.play();if(q&&q.catch)q.catch(function(){})}}
if(holder&&'IntersectionObserver' in window){
  new IntersectionObserver(function(es){es.forEach(function(e){
    if(e.isIntersecting&&!reduce.matches){
      if(!vid){vid=document.createElement('video');vid.muted=true;vid.loop=true;vid.playsInline=true;vid.setAttribute('muted','');vid.setAttribute('playsinline','');vid.setAttribute('aria-hidden','true');vid.preload='metadata';
        if(holder.dataset.webm&&vid.canPlayType('video/webm; codecs="vp9"')){var w=document.createElement('source');w.src=holder.dataset.webm;w.type='video/webm';vid.appendChild(w)}
        var m=document.createElement('source');m.src=holder.dataset.mp4;m.type='video/mp4';vid.appendChild(m);holder.appendChild(vid)}
      play();
    }else if(vid){vid.pause()}
  })},{threshold:0.25}).observe(holder);
  document.addEventListener('visibilitychange',function(){if(!vid)return;if(document.hidden)vid.pause();else play()});
}
})();
