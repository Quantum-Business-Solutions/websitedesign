LAUNCH PACKAGE: what to do at launch
=====================================

These files are for the live domain (https://www.dmp.com). The preview build under /clean, /showcase and /press is a staging copy and is
deliberately not ready to be indexed:

  1. Every page carries <meta name="robots" content="noindex, nofollow">. Remove it on launch.
  2. <link rel="canonical">, og:url and og:image point at the staging host. At launch they must be rewritten to https://www.dmp.com.
  3. The preview direction switcher (the "Direction" bar) must be removed.

scripts/launch_rewrite.py does all three for one direction folder:

  python3 scripts/launch_rewrite.py <built-direction-folder> https://www.dmp.com <output-folder>

It writes a launch-ready copy and leaves the preview untouched. Then:

  - robots.txt, sitemap.xml (145 URLs, lastmod 2026-11-09) and llms.txt in this folder go in the site root.
  - Apply the 301 map in redirects.csv (old URL to new path; rows marked 410 return Gone).
  - Submit sitemap.xml in Google Search Console and Bing Webmaster Tools.
  - Article markup carries no datePublished, dateModified or author until DMP supplies them (see the TO_CONFIRM list).
