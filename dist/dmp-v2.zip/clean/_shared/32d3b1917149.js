(function(){
var d=document,rm=matchMedia('(prefers-reduced-motion: reduce)').matches,io='IntersectionObserver' in window;
function $(r,s){return r.querySelector(s)}function $$(r,s){return Array.prototype.slice.call(r.querySelectorAll(s))}
function esc(t){return String(t).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
/* header offset for sticky bars */
function top(){var h=$(d,'.q-header'),v=0;if(h){var p=getComputedStyle(h).position;if(p==='sticky'||p==='fixed')v=Math.round(h.getBoundingClientRect().height)}d.documentElement.style.setProperty('--p2-top',v+'px')}
top();addEventListener('resize',top);var tr=0;addEventListener('scroll',function(){if(!tr)tr=requestAnimationFrame(function(){tr=0;top()})},{passive:true});
/* reveal on scroll */
function watch(els,cb,th){if(!io||rm){els.forEach(function(e){cb(e,true)});return}var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){o.unobserve(e.target);cb(e.target,false)}})},{threshold:th||.18,rootMargin:'0px 0px -6% 0px'});els.forEach(function(e){o.observe(e)})}
$$(d,'[data-p2=reveal]').forEach(function(box){var kids=$$(box,':scope > li');kids.forEach(function(k,i){k.style.setProperty('--i',i);if(!rm&&io)k.classList.add('p2-rv')});if(rm||!io)return;watch(kids,function(k){k.classList.add('in')},.2)});
$$(d,'[data-p2=files]').forEach(function(f){if(rm||!io){f.classList.add('in');return}watch([f],function(e){e.classList.add('in')},.25)});
/* day timeline */
$$(d,'[data-p2=tl]').forEach(function(tl){var ms=$$(tl,'.p2-m');if(rm||!io){ms.forEach(function(m){m.classList.add('in')});return}
var raf=0;function upd(){raf=0;var line=innerHeight*.62,r=tl.getBoundingClientRect();ms.forEach(function(m){var b=m.getBoundingClientRect();if(b.top+30<line)m.classList.add('in')});var p=(line-r.top-28)/Math.max(1,r.height-56);tl.style.setProperty('--p',Math.max(0,Math.min(1,p)).toFixed(3))}
addEventListener('scroll',function(){if(!raf)raf=requestAnimationFrame(upd)},{passive:true});addEventListener('resize',upd);upd()});
/* count-up numerals */
$$(d,'[data-p2=nums] .p2-big').forEach(function(el){if(rm||!io)return;var to=parseFloat(el.getAttribute('data-to')),suf=el.getAttribute('data-suf')||'',final=el.textContent;el.textContent='0'+suf;watch([el],function(e){var t0=null;function st(ts){if(t0===null)t0=ts;var k=Math.min(1,(ts-t0)/1700);k=1-Math.pow(1-k,3);e.textContent=Math.round(to*k)+suf;if(k<1)requestAnimationFrame(st);else e.textContent=final}requestAnimationFrame(st)},.5)});
/* contact router */
$$(d,'[data-p2=router]').forEach(function(root){var picks=$$(root,'.p2-rt-pick'),panels=$$(root,'.p2-rt-panel'),stage=$(root,'.p2-rt-stage');
function sel(i,focus){picks.forEach(function(p,j){var on=j===i;p.setAttribute('aria-selected',on?'true':'false');p.tabIndex=on||(i<0&&j===0)?0:-1});panels.forEach(function(p,j){p.classList.toggle('on',j===i)});root.classList.add('has');if(focus)picks[i].focus();if(innerWidth<=900&&stage){setTimeout(function(){var r=stage.getBoundingClientRect();if(r.top>innerHeight*.6||r.top<0)stage.scrollIntoView({behavior:rm?'auto':'smooth',block:'start'})},60)}status()}
picks.forEach(function(p,i){p.tabIndex=i===0?0:-1;p.addEventListener('click',function(){sel(i)});p.addEventListener('keydown',function(e){var n=picks.length,k=e.key;if(k==='ArrowDown'||k==='ArrowRight'){e.preventDefault();sel((i+1)%n,true)}else if(k==='ArrowUp'||k==='ArrowLeft'){e.preventDefault();sel((i+n-1)%n,true)}else if(k==='Home'){e.preventDefault();sel(0,true)}else if(k==='End'){e.preventDefault();sel(n-1,true)}})})});
/* open now, from the posted hours, Central time */
var HOL={'2026-01-01':1,'2026-05-25':1,'2026-07-03':1,'2026-09-07':1,'2026-11-26':1,'2026-11-27':1,'2026-12-24':1,'2026-12-25':1};
function central(){try{var f=new Intl.DateTimeFormat('en-US',{timeZone:'America/Chicago',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',weekday:'short',hourCycle:'h23'}),o={};f.formatToParts(new Date()).forEach(function(p){o[p.type]=p.value});return{wd:o.weekday,date:o.year+'-'+o.month+'-'+o.day,min:(+o.hour)*60+(+o.minute)}}catch(e){return null}}
function parseH(t){var m=String(t).match(/(\d{1,2})(?::(\d{2}))?\s*a\.m\.\s*to\s*(\d{1,2})(?::(\d{2}))?\s*p\.m\./);if(!m)return null;var s=(+m[1]%12)*60+(+(m[2]||0)),e=((+m[3]%12)+12)*60+(+(m[4]||0));return{s:s,e:e,sl:m[1]+(m[2]?':'+m[2]:'')+' a.m.'}}
function state(h){var c=central(),p=parseH(h);if(!c||!p)return null;if(HOL[c.date])return{o:false,t:'Closed today (holiday)'};if(c.wd==='Sat'||c.wd==='Sun')return{o:false,t:'Closed now'};if(c.min>=p.s&&c.min<p.e)return{o:true,t:'Open now'};if(c.min<p.s)return{o:false,t:'Opens '+p.sl+' Central'};return{o:false,t:'Closed now'}}
function paint(el,st){if(!st)return;el.hidden=false;el.textContent=st.t;el.classList.toggle('is-closed',!st.o)}
var lines=[];$$(d,'.cd-line').forEach(function(l){var h=$(l,'.cd-hrs');if(!h||!parseH(h.textContent))return;var w=d.createElement('div');w.className='p2-hrow';h.parentNode.insertBefore(w,h);w.appendChild(h);var b=d.createElement('span');b.className='p2-open';b.hidden=true;b.setAttribute('role','status');w.appendChild(b);lines.push([b,h.textContent])});
function status(){$$(d,'.p2-open[data-hours]').forEach(function(el){paint(el,state(el.getAttribute('data-hours')))});lines.forEach(function(x){paint(x[0],state(x[1]))})}
status();setInterval(status,60000);
/* support chooser */
$$(d,'[data-p2=chooser]').forEach(function(root){var inp=$(root,'input'),ul=$(root,'.p2-res'),em=$(root,'.p2-sempty'),idx=[],sel=-1;try{idx=JSON.parse($(root,'.p2-idx').textContent)}catch(e){}
function hl(t,ts){var s=esc(t);ts.forEach(function(q){if(q.length>1)s=s.replace(new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig'),'<mark>$1</mark>')});return s}
function run(){var q=inp.value.trim().toLowerCase(),ts=q.split(/\s+/).filter(Boolean);sel=-1;if(!ts.length){ul.hidden=true;em.hidden=true;ul.innerHTML='';return}
var r=[];idx.forEach(function(it){var t=it.t.toLowerCase(),k=(it.k||'').toLowerCase(),dd=it.d.toLowerCase(),sc=0,ok=true;ts.forEach(function(w){var s=0;if(t.indexOf(w)>-1)s+=3;if(k.indexOf(w)>-1)s+=2;if(dd.indexOf(w)>-1)s+=1;if(!s)ok=false;sc+=s});if(ok)r.push([sc,it])});r.sort(function(a,b){return b[0]-a[0]});r=r.slice(0,6);
ul.innerHTML=r.map(function(x){var it=x[1],ext=/^https?:/.test(it.h)?' rel="noopener"':'';return '<li><a href="'+esc(it.h)+'"'+ext+'><span><b>'+hl(it.t,ts)+'</b><small>'+hl(it.d,ts)+'</small></span><span class="g" aria-hidden="true">&rarr;</span></a></li>'}).join('');ul.hidden=!r.length;em.hidden=!!r.length}
function mv(n){var a=$$(ul,'a');if(!a.length)return;a.forEach(function(x){x.classList.remove('sel')});sel=(sel+n+a.length)%a.length;a[sel].classList.add('sel');a[sel].scrollIntoView({block:'nearest'})}
inp.addEventListener('input',run);inp.addEventListener('keydown',function(e){if(e.key==='ArrowDown'){e.preventDefault();mv(1)}else if(e.key==='ArrowUp'){e.preventDefault();mv(-1)}else if(e.key==='Enter'){var a=$$(ul,'a');var t=a[sel<0?0:sel];if(t){e.preventDefault();location.href=t.href}}else if(e.key==='Escape'){inp.value='';run()}})});
/* training board */
$$(d,'[data-p2=board]').forEach(function(root){var c=central(),today=c?c.date:new Date().toISOString().slice(0,10),first=null;$$(root,'.p2-tk').forEach(function(t){var e=t.getAttribute('data-end');if(e<today)t.classList.add('is-past');else if(!first){first=t;t.classList.add('is-next');$(t,'.p2-tk-next').hidden=false}})});
/* blog toc */
$$(d,'[data-p2=toc]').forEach(function(nav){var links=$$(nav,'a'),secs=links.map(function(a){return d.getElementById(a.getAttribute('data-t'))}),strip=$(nav,'.p2-toc-s'),raf=0,cur=-1;
function upd(){raf=0;var off=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--p2-top'))||0)+nav.offsetHeight+30,a=0;secs.forEach(function(s,i){if(s&&s.getBoundingClientRect().top<=off)a=i});if(scrollY<20)a=0;if(a!==cur){cur=a;links.forEach(function(l,i){l.classList.toggle('on',i===a);if(i===a)l.setAttribute('aria-current','true');else l.removeAttribute('aria-current')});var l=links[a];strip.scrollTo?strip.scrollTo({left:Math.max(0,l.offsetLeft-strip.clientWidth/2+l.offsetWidth/2),behavior:rm?'auto':'smooth'}):0}
var m=$(d,'main'),r=m.getBoundingClientRect(),p=(-r.top+innerHeight*.3)/Math.max(1,r.height-innerHeight*.3);nav.style.setProperty('--p',Math.max(0,Math.min(1,p)).toFixed(3))}
addEventListener('scroll',function(){if(!raf)raf=requestAnimationFrame(upd)},{passive:true});addEventListener('resize',upd);upd()});
/* flip cards */
$$(d,'[data-p2=flip] .p2-fl-in').forEach(function(b){b.addEventListener('click',function(){b.setAttribute('aria-pressed',b.getAttribute('aria-pressed')==='true'?'false':'true')})});
/* finder: why this and compare tray */
$$(d,'[data-mo=finder]').forEach(function(root){var dj=$(root,'.p2-fdata'),tray=$(root,'[data-p2=tray]');if(!dj||!tray)return;var data={};try{data=JSON.parse(dj.textContent)}catch(e){}
var btns=$$(root,'.p2-cmp'),pick=[],bar=tray.querySelector('.p2-tray-sel'),cnt=tray.querySelector('[data-c]'),go=tray.querySelector('.p2-tray-go'),panel=tray.querySelector('.p2-tray-panel'),scroll=tray.querySelector('.p2-tray-scroll');
function why(){var b=$(root,'.mo-fnd-row[data-kind=b] .mo-chip[aria-pressed=true]'),n=$(root,'.mo-fnd-row[data-kind=n] .mo-chip[aria-pressed=true]'),kb=b?b.getAttribute('data-k'):'all',kn=n?n.getAttribute('data-k'):'all';$$(root,'.p2-wc').forEach(function(c){var k=c.getAttribute('data-k');c.classList.toggle('on',k==='b:'+kb||k==='n:'+kn)})}
root.addEventListener('click',function(e){if(e.target.closest&&e.target.closest('.mo-chip,.mo-reset'))setTimeout(why,0)});why();
function table(){var items=pick.map(function(i){return data[i]}),labels=[],cnt={};items.forEach(function(it){it.sp.forEach(function(s){if(!cnt[s[0]]){cnt[s[0]]=0;labels.push(s[0])}cnt[s[0]]++})});labels.sort(function(a,b){return cnt[b]-cnt[a]});var shared=labels.filter(function(l){return cnt[l]>1});labels=shared.length>=4?shared.slice(0,10):labels.slice(0,8);
var h='<table class="p2-cmp-t"><thead><tr><th scope="col"><span class="mo-vh">Spec</span></th>'+items.map(function(it){return '<th scope="col"><a href="'+esc(it.h)+'">'+esc(it.n)+'</a>'+(it.soon?'<small>Coming soon, not orderable</small>':'<small>View product</small>')+'</th>'}).join('')+'</tr></thead><tbody>';
h+='<tr><th scope="row">Product type</th>'+items.map(function(it){return '<td>'+esc(it.t.join(', '))+'</td>'}).join('')+'</tr><tr><th scope="row">Systems</th>'+items.map(function(it){return '<td>'+esc(it.s.join(', '))+'</td>'}).join('')+'</tr>';
labels.forEach(function(l){h+='<tr><th scope="row">'+esc(l)+'</th>'+items.map(function(it){var v=null;it.sp.forEach(function(s){if(s[0]===l)v=s[1]});return v?'<td>'+esc(v)+'</td>':'<td class="na">Not listed</td>'}).join('')+'</tr>'});
scroll.innerHTML=h+'</tbody></table>'}
function ui(){tray.hidden=!pick.length;cnt.textContent=pick.length+' of 3 selected';go.disabled=pick.length<2;bar.innerHTML=pick.map(function(i){return '<li><span>'+esc(data[i].n)+'</span><button type="button" data-r="'+i+'" aria-label="Remove '+esc(data[i].n)+' from comparison">&times;</button></li>'}).join('');
btns.forEach(function(b){var on=pick.indexOf(b.getAttribute('data-i'))>-1;b.setAttribute('aria-pressed',on?'true':'false');b.setAttribute('aria-disabled',!on&&pick.length>=3?'true':'false')});
if(!panel.hidden){if(pick.length<2){panel.hidden=true;go.textContent='Compare specs';gox(false)}else table()}}
var lastB=null;panel.id=panel.id||'p2-tray-panel';go.setAttribute('aria-controls',panel.id);go.setAttribute('aria-expanded','false');
function gox(o){go.setAttribute('aria-expanded',o?'true':'false')}
btns.forEach(function(b){b.addEventListener('click',function(){var i=b.getAttribute('data-i'),k=pick.indexOf(i);if(k>-1)pick.splice(k,1);else if(pick.length<3)pick.push(i);else return;lastB=b;ui()})});
bar.addEventListener('click',function(e){var r=e.target.getAttribute&&e.target.getAttribute('data-r');if(r===null||r===undefined)return;pick.splice(pick.indexOf(r),1);ui();var nx=bar.querySelector('button');if(nx)nx.focus();else if(lastB)lastB.focus()});
go.addEventListener('click',function(){if(panel.hidden){table();panel.hidden=false;go.textContent='Hide comparison';gox(true)}else{panel.hidden=true;go.textContent='Compare specs';gox(false)}});
tray.querySelector('.p2-tray-clear').addEventListener('click',function(){pick=[];panel.hidden=true;go.textContent='Compare specs';gox(false);ui();if(lastB)lastB.focus()});
d.addEventListener('keydown',function(e){if(e.key==='Escape'&&!panel.hidden){panel.hidden=true;go.textContent='Compare specs';gox(false);if(tray.contains(d.activeElement))go.focus()}})});
})();