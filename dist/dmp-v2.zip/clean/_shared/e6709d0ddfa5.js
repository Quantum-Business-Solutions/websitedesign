
(function(){
var rm=matchMedia('(prefers-reduced-motion: reduce)').matches;
/* pinned story: the step in the middle band of the viewport owns the stage */
document.querySelectorAll('.dw2-story').forEach(function(sec){
  var stage=sec.querySelector('.dw2-st-stage'),steps=[].slice.call(sec.querySelectorAll('.dw2-st-step')),
      chips=[].slice.call(sec.querySelectorAll('.dw2-chip')),ticks=[].slice.call(sec.querySelectorAll('.dw2-st-prog i'));
  if(!stage||!steps.length)return;
  function set(i){stage.setAttribute('data-step',i);
    steps.forEach(function(s,k){s.classList.toggle('on',k===i)});
    chips.forEach(function(c,k){c.classList.toggle('on',k===i)});
    ticks.forEach(function(t,k){t.classList.toggle('on',k<=i)});}
  if(!('IntersectionObserver' in window))return;
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting)set(+e.target.getAttribute('data-i'))})},{rootMargin:'-44% 0px -44% 0px'});
  steps.forEach(function(s){io.observe(s)});
});
/* distributor map: hover and focus work in CSS; click toggles for touch, Escape closes */
document.querySelectorAll('.dw2-map').forEach(function(map){
  var pins=[].slice.call(map.querySelectorAll('.dw2-pin'));
  function closeAll(except){pins.forEach(function(p){if(p!==except){p.classList.remove('open');p.querySelector('.dw2-pb').setAttribute('aria-expanded','false')}})}
  pins.forEach(function(p){
    var b=p.querySelector('.dw2-pb');
    b.addEventListener('click',function(e){var o=!p.classList.contains('open');p.classList.remove('off');closeAll(p);p.classList.toggle('open',o);b.setAttribute('aria-expanded',o?'true':'false');e.stopPropagation()});
    p.addEventListener('mouseenter',function(){closeAll(p)});p.addEventListener('focusin',function(){closeAll(p)});
    p.addEventListener('mouseleave',function(){p.classList.remove('off')});
    p.addEventListener('focusout',function(){setTimeout(function(){if(!p.contains(document.activeElement)){p.classList.remove('off')}},0)});
  });
  document.addEventListener('click',function(e){if(!map.contains(e.target))closeAll()});
  map.addEventListener('keydown',function(e){
    if(e.key==='Escape'){var p=e.target.closest&&e.target.closest('.dw2-pin');closeAll();if(p){p.classList.add('off');p.classList.remove('open');p.querySelector('.dw2-pb').focus()}}
    if(e.key==='ArrowRight'||e.key==='ArrowDown'||e.key==='ArrowLeft'||e.key==='ArrowUp'){
      var cur=pins.indexOf(e.target.closest('.dw2-pin'));if(cur<0)return;
      var d=(e.key==='ArrowRight'||e.key==='ArrowDown')?1:-1,n=pins[(cur+d+pins.length)%pins.length];n.querySelector('.dw2-pb').focus();e.preventDefault()}
  });
});
})();
