
(function(){
var d=document,de=d.documentElement,R=function(q,c){return [].slice.call((c||d).querySelectorAll(q))};
var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
de.classList.add('dw-js');

/* ---- building cutaway ---- */
R('[data-dw=bld]').forEach(function(root){
var sec=root.closest('.dw')||root,hs=R('.dw-hs',root),bs=R('.dw-lb',root),lis=R('.dw-li',root),n=lis.length,ids=lis.map(function(l){return l.getAttribute('data-z')}),
tbtn=root.querySelector('.dw-tbtn'),tn=root.querySelector('.dw-tn'),tl=root.querySelector('.dw-tl'),cur=-1,timer=0,hov=0,STEP=5500;
sec.classList.add('dw-on');sec.style.setProperty('--dw-step',STEP+'ms');
function act(i){if(i===cur)return;cur=i;lis.forEach(function(l,k){l.classList.toggle('on',k===i)});
hs.forEach(function(h,k){h.classList.toggle('on',k===i);h.setAttribute('aria-pressed',k===i?'true':'false');h.tabIndex=k===i?0:-1});
bs.forEach(function(b,k){b.setAttribute('aria-expanded',k===i?'true':'false')});
sec.setAttribute('data-act',ids[i]);tn.textContent='Stop '+(i+1)+' of '+n;tl.textContent=bs[i].querySelector('.t').textContent;
if(timer){var p=sec.querySelector('.dw-prog i');if(p){p.style.animation='none';void p.offsetWidth;p.style.animation=''}}}
function stop(){if(timer){clearInterval(timer);timer=0}sec.classList.remove('touring');tbtn.setAttribute('aria-pressed','false');tbtn.querySelector('span').textContent='Take the guided tour';tbtn.querySelector('svg').innerHTML='<path d="M6 4l10 6-10 6z" fill="currentColor"/>'}
function step(){act((cur+1)%n)}
function start(){stop();timer=setInterval(step,STEP);sec.classList.add('touring');tbtn.setAttribute('aria-pressed','true');tbtn.querySelector('span').textContent='Pause the tour';tbtn.querySelector('svg').innerHTML='<path d="M5 4h3.5v12H5zM11.5 4H15v12h-3.5z" fill="currentColor"/>';var f=cur<0||cur===n-1?0:cur+1;if(f===cur){}else{act(f)}}
tbtn.addEventListener('click',function(){timer?stop():start()});
hs.forEach(function(h,k){
h.addEventListener('click',function(){stop();act(k)});
h.addEventListener('focus',function(){if(!timer)act(k)});
h.addEventListener('pointerenter',function(e){if(e.pointerType==='touch')return;clearTimeout(hov);hov=setTimeout(function(){stop();act(k)},60)});
h.addEventListener('pointerleave',function(){clearTimeout(hov)});
h.addEventListener('keydown',function(e){var t=null;
if(e.key==='ArrowRight'||e.key==='ArrowDown')t=hs[(k+1)%n];else if(e.key==='ArrowLeft'||e.key==='ArrowUp')t=hs[(k+n-1)%n];else if(e.key==='Home')t=hs[0];else if(e.key==='End')t=hs[n-1];
if(t){e.preventDefault();stop();t.focus();act(+t.getAttribute('data-i'))}})});
bs.forEach(function(b,k){b.addEventListener('click',function(){stop();act(k)});
b.addEventListener('keydown',function(e){var t=null;if(e.key==='ArrowDown')t=bs[(k+1)%n];else if(e.key==='ArrowUp')t=bs[(k+n-1)%n];if(t){e.preventDefault();t.focus()}})});
d.addEventListener('keydown',function(e){if(e.key==='Escape'&&timer&&root.contains(d.activeElement))stop()});
root.addEventListener('focusin',function(e){var t=e.target;if(timer&&t!==tbtn){stop();if(t.classList&&t.classList.contains('dw-hs'))act(+t.getAttribute('data-i'))}});
if('IntersectionObserver' in window)new IntersectionObserver(function(es){if(!es[0].isIntersecting&&timer)stop()},{threshold:.1}).observe(root);
act(0)});

/* ---- anatomy leader lines ---- */
R('[data-dw=an]').forEach(function(fig){
var svg=fig.querySelector('.dw-an-ln'),fr=fig.querySelector('.dw-an-frame'),cos=R('.dw-co',fig),NS='http://www.w3.org/2000/svg',raf=0;
function draw(){raf=0;svg.innerHTML='';if(innerWidth<=1000)return;var f=fig.getBoundingClientRect(),b=fr.getBoundingClientRect();
var L=cos.filter(function(c){return c.parentNode.classList.contains('dw-an-l')}),Rr=cos.filter(function(c){return c.parentNode.classList.contains('dw-an-r')});
[[L,true],[Rr,false]].forEach(function(g){var arr=g[0],left=g[1],m=arr.length;arr.forEach(function(c,k){
var r=c.getBoundingClientRect(),sx=(left?r.right:r.left)-f.left,sy=r.top+Math.min(r.height/2,32)-f.top,tx=(left?b.left:b.right)-f.left,ty=b.top-f.top+b.height*(k+1)/(m+1),mx=(sx+tx)/2;
var p=d.createElementNS(NS,'path');p.setAttribute('d','M'+sx+' '+sy+'H'+mx+'V'+ty+'H'+tx);p.setAttribute('data-k',c.getAttribute('data-k'));svg.appendChild(p);
var gk=d.createElementNS(NS,'g');gk.setAttribute('data-k',c.getAttribute('data-k'));var ci=d.createElementNS(NS,'circle');ci.setAttribute('cx',tx);ci.setAttribute('cy',ty);ci.setAttribute('r',13);var tx2=d.createElementNS(NS,'text');tx2.setAttribute('x',tx);tx2.setAttribute('y',ty);tx2.textContent=(+c.getAttribute('data-k')+1);gk.appendChild(ci);gk.appendChild(tx2);svg.appendChild(gk)})})}
function q(){if(!raf)raf=requestAnimationFrame(draw)}
cos.forEach(function(c){var k=c.getAttribute('data-k');function on(v){c.classList.toggle('hot',v);R('path[data-k="'+k+'"]',svg).forEach(function(p){p.classList.toggle('hot',v)})}
c.addEventListener('pointerenter',function(){on(true)});c.addEventListener('pointerleave',function(){on(false)})});
addEventListener('resize',q);if('ResizeObserver' in window)new ResizeObserver(q).observe(fig);var im=fr.querySelector('img');if(im&&!im.complete)im.addEventListener('load',q);q();setTimeout(q,400)});

/* ---- mega menus ---- */
var items=R('.q-header .q-nav-item[data-dwm]'),hd=d.querySelector('.q-header'),scrim=null,openIt=null,tIn=0,tOut=0,lastPT='mouse';
if(items.length){scrim=d.createElement('div');scrim.className='dw-scrim';scrim.setAttribute('aria-hidden','true');d.body.appendChild(scrim);scrim.addEventListener('click',function(){close(true)})}
function trig(it){return it.querySelector(':scope>a')}
function pos(){if(!hd||!scrim)return;var hi=hd.querySelector('.q-header-in').getBoundingClientRect();de.style.setProperty('--dw-scrim',Math.round(hi.bottom)+'px')}
function setOpen(it){if(openIt&&openIt!==it){openIt.classList.remove('dw-open');trig(openIt).setAttribute('aria-expanded','false')}
openIt=it;if(it){pos();it.classList.add('dw-open');trig(it).setAttribute('aria-expanded','true');scrim.classList.add('on')}else{scrim.classList.remove('on')}}
function close(focus){var it=openIt;if(!it)return;it.classList.remove('dw-open');trig(it).setAttribute('aria-expanded','false');scrim.classList.remove('on');openIt=null;if(focus)trig(it).focus()}
function foc(p){return R('a[href]',p).filter(function(a){return a.offsetParent!==null||getComputedStyle(a).position==='fixed'})}
items.forEach(function(it,ix){var a=trig(it),p=it.querySelector('.dw-mega');a.setAttribute('aria-expanded','false');if(p)a.setAttribute('aria-controls',p.id);
it.addEventListener('pointerenter',function(e){if(e.pointerType==='touch')return;lastPT='mouse';clearTimeout(tOut);clearTimeout(tIn);if(openIt&&openIt!==it)setOpen(it);else if(!openIt)tIn=setTimeout(function(){setOpen(it)},110)});
it.addEventListener('pointerleave',function(e){if(e.pointerType==='touch')return;clearTimeout(tIn);tOut=setTimeout(function(){if(openIt===it)close(false)},230)});
a.addEventListener('pointerdown',function(e){lastPT=e.pointerType});
a.addEventListener('click',function(e){if(lastPT==='touch'&&innerWidth>1024&&openIt!==it){e.preventDefault();setOpen(it)}});
a.addEventListener('keydown',function(e){var k=e.key,top=R('.q-header .q-nav>a,.q-header .q-nav-item>a');var i=top.indexOf(a);
if(k==='ArrowDown'||k===' '){e.preventDefault();setOpen(it);var f=foc(p);if(f[0])f[0].focus()}
else if(k==='ArrowRight'||k==='ArrowLeft'){e.preventDefault();var t=top[(i+(k==='ArrowRight'?1:top.length-1))%top.length];if(openIt)close(false);t.focus()}
else if(k==='Escape'&&openIt){e.preventDefault();close(true)}});
if(p)p.addEventListener('keydown',function(e){var k=e.key,f=foc(p),i=f.indexOf(d.activeElement);
if(k==='Escape'){e.preventDefault();close(true)}
else if(k==='ArrowDown'||k==='ArrowRight'){e.preventDefault();f[(i+1)%f.length].focus()}
else if(k==='ArrowUp'||k==='ArrowLeft'){e.preventDefault();if(i<=0){a.focus()}else f[i-1].focus()}
else if(k==='Home'){e.preventDefault();f[0].focus()}else if(k==='End'){e.preventDefault();f[f.length-1].focus()}});
it.addEventListener('focusout',function(e){var to=e.relatedTarget;if(openIt===it&&(!to||!it.contains(to)))setTimeout(function(){if(openIt===it&&!it.contains(d.activeElement))close(false)},0)});
a.addEventListener('focus',function(){if(openIt&&openIt!==it)close(false)})});
d.addEventListener('keydown',function(e){if(e.key==='Escape'&&openIt)close(true)});
d.addEventListener('pointerdown',function(e){if(openIt&&!openIt.contains(e.target))close(false)});
addEventListener('resize',function(){if(innerWidth<=1024)close(false)});

/* ---- header that condenses (the box keeps its height, so nothing under it moves) ---- */
if(hd){var hi=hd.querySelector('.q-header-in'),ut=hd.querySelector('.pv-util'),cond=false,ticking=false;
function meas(){hd.classList.remove('dw-fix','dw-cond');cond=false;hd.style.removeProperty('--dw-h0');
var uh=ut?ut.offsetHeight:0,h0=hd.offsetHeight,hin=hi.offsetHeight,hin1=Math.round(hin*.78);
hd.style.setProperty('--dw-h0',h0+'px');hd.style.setProperty('--dw-u',uh+'px');hd.style.setProperty('--dw-hin1',hin1+'px');hd.style.setProperty('--dw-h1',hin1+'px');
hd.classList.add('dw-fix');upd(true)}
function pp(v){de.style.setProperty('--pp-hdr',v+'px');de.style.setProperty('--p2-top',v+'px')}
function upd(force){ticking=false;var y=scrollY,c=cond;if(y>80)c=true;else if(y<36)c=false;if(c!==cond||force){cond=c;hd.classList.toggle('dw-cond',c);pp(parseInt(hd.style.getPropertyValue(c?'--dw-h1':'--dw-h0'))||0);pos()}}
if(ut)ut.addEventListener('focusin',function(){if(cond)scrollTo(0,0)});
meas();addEventListener('scroll',function(){if(!ticking){ticking=true;requestAnimationFrame(function(){upd(false)})}},{passive:true});
var rt=0;addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(meas,150)});
if(d.fonts&&d.fonts.ready)d.fonts.ready.then(function(){meas()})}

/* ---- dark stage texture and cursor spotlight ---- */
var fine=matchMedia('(hover: hover) and (pointer: fine)').matches;
var io=('IntersectionObserver' in window)?new IntersectionObserver(function(es){es.forEach(function(e){var f=e.target.querySelector(':scope>.dw-fx');if(f)f.classList.toggle('vis',e.isIntersecting)})}):{observe:function(){}};
R('.lf-dark,.pv-dark').forEach(function(s){if(s.querySelector(':scope>.dw-fx'))return;
var fx=d.createElement('i');fx.className='dw-fx';fx.setAttribute('aria-hidden','true');fx.innerHTML='<b class="dw-fx-mesh"></b><b class="dw-fx-grain"></b><b class="dw-fx-spot"></b>';s.insertBefore(fx,s.firstChild);s.classList.add('dw-stagefx');
if(fine&&!reduce){var raf=0,ex=0,ey=0;s.addEventListener('pointermove',function(e){if(e.pointerType==='touch')return;ex=e.clientX;ey=e.clientY;if(!raf)raf=requestAnimationFrame(function(){raf=0;var r=s.getBoundingClientRect();fx.style.setProperty('--dw-x',(ex-r.left)+'px');fx.style.setProperty('--dw-y',(ey-r.top)+'px');fx.classList.add('hov')})},{passive:true});
s.addEventListener('pointerleave',function(){fx.classList.remove('hov')})}
io.observe(s)});
})();
