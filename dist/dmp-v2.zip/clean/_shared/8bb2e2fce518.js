(function(){var h=document.getElementById("hero-layered");if(!h)return;var rm=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(pointer:fine) and (min-width:1025px)').matches;
if(!rm&&fine){var g=h.querySelector('.glow');h.addEventListener('pointermove',function(e){var r=h.getBoundingClientRect();h.style.setProperty('--mx',((e.clientX-r.left)/r.width*100).toFixed(1)+'%');h.style.setProperty('--my',((e.clientY-r.top)/r.height*100).toFixed(1)+'%');
h.querySelectorAll('.pv-depth').forEach(function(c){var d=+c.getAttribute('data-depth')||1,x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform='translate3d('+(-x*10*d).toFixed(1)+'px,'+(-y*10*d).toFixed(1)+'px,0) rotateX('+(y*-4).toFixed(2)+'deg) rotateY('+(x*5).toFixed(2)+'deg)'})});
h.addEventListener('pointerleave',function(){h.querySelectorAll('.pv-depth').forEach(function(c){c.style.transform=''})})}
var hb=h.querySelector('.bg.hv');if(hb){var mqW=matchMedia('(min-width:768px)'),mqR=matchMedia('(prefers-reduced-motion: reduce)'),vd=null,vio=null;
function hvOn(){if(vd||!mqW.matches||mqR.matches)return;vd=document.createElement('video');vd.muted=true;vd.loop=true;vd.playsInline=true;vd.autoplay=true;vd.preload='metadata';vd.setAttribute('aria-hidden','true');vd.setAttribute('muted','');vd.setAttribute('playsinline','');vd.disablePictureInPicture=true;
if(hb.dataset.poster)vd.poster=hb.dataset.poster;
if(hb.dataset.webm&&vd.canPlayType('video/webm; codecs="vp9"')){var w=document.createElement('source');w.src=hb.dataset.webm;w.type='video/webm; codecs="vp9"';vd.appendChild(w)}
var m=document.createElement('source');m.src=hb.dataset.mp4;m.type='video/mp4';vd.appendChild(m);
vd.addEventListener('playing',function(){vd.classList.add('on')});hb.appendChild(vd);var pr=vd.play();if(pr&&pr.catch)pr.catch(function(){});
if('IntersectionObserver' in window){vio=new IntersectionObserver(function(es){es.forEach(function(e){if(!vd)return;if(e.isIntersecting){var q=vd.play();if(q&&q.catch)q.catch(function(){})}else vd.pause()})});vio.observe(h)}}
function hvOff(){if(!vd)return;if(vio){vio.disconnect();vio=null}vd.pause();vd.remove();vd=null}
function hvSync(){(mqW.matches&&!mqR.matches)?hvOn():hvOff()}
hvSync();[mqW,mqR].forEach(function(m){m.addEventListener?m.addEventListener('change',hvSync):m.addListener(hvSync)})}
var cv=h.querySelector('canvas.net');if(cv&&!rm&&cv.getContext){var cx=cv.getContext('2d'),W,H,P=[],run=false,raf=0,col=getComputedStyle(h).getPropertyValue('--q-gold').trim()||'#65bc7b';
function size(){var r=h.getBoundingClientRect();W=cv.width=Math.floor(r.width);H=cv.height=Math.floor(r.height);var n=W<768?22:W<1200?40:56;P=[];for(var i=0;i<n;i++)P.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.22,vy:(Math.random()-.5)*.22,r:1.2+Math.random()*1.8})}
function tick(){if(!run)return;cx.clearRect(0,0,W,H);var i,j,a,b,d;for(i=0;i<P.length;i++){a=P[i];a.x+=a.vx;a.y+=a.vy;if(a.x<0||a.x>W)a.vx*=-1;if(a.y<0||a.y>H)a.vy*=-1}
cx.lineWidth=1;for(i=0;i<P.length;i++){a=P[i];for(j=i+1;j<P.length;j++){b=P[j];d=Math.hypot(a.x-b.x,a.y-b.y);if(d<150){cx.globalAlpha=(1-d/150)*.28;cx.strokeStyle=col;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(b.x,b.y);cx.stroke()}}}
for(i=0;i<P.length;i++){a=P[i];cx.globalAlpha=.75;cx.fillStyle=col;cx.beginPath();cx.arc(a.x,a.y,a.r,0,6.283);cx.fill()}cx.globalAlpha=1;raf=requestAnimationFrame(tick)}
size();addEventListener('resize',size,{passive:true});
if('IntersectionObserver' in window){new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting&&!run){run=true;tick()}else if(!e.isIntersecting){run=false;cancelAnimationFrame(raf)}})}).observe(h)}else{run=true;tick()}}})();