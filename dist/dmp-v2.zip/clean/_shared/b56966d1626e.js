(function(){var d=document.documentElement;d.classList.add('pv-js');var rm=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(pointer:fine) and (min-width:1025px)').matches,dir=d.getAttribute('data-dir')||'';
/* reveal below the first section, staggered per parent */
if(!rm&&'IntersectionObserver' in window){var first=document.querySelector('main > section');
var sel='main .q-card,main .pv-stat,main .pv-svc a,main .pv-seal .item,main .pv-flow .node,main .pv-fleet .dev,main .pv-hot-list li,main .pv-wheel,main .pv-ba,main .pv-3d,main .pv-cmp,main .pv-story .stage,main .pv-map-svg,main .pv-post,main .pv-quote,main .pv-cs,main .pv-metric,main section .q-h2,main section .q-lead,main .pv-proof b';
var els=[].slice.call(document.querySelectorAll(sel)).filter(function(e){return !(first&&first.contains(e))&&!e.closest('.pv-lh')});
els.forEach(function(e){var p=e.parentElement;p.__pvN=p.__pvN||0;e.style.setProperty('--i',Math.min(p.__pvN,8));p.__pvN++;e.classList.add('pv-rv')});
var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting||x.boundingClientRect.top<0){x.target.classList.add('in');io.unobserve(x.target)}})},{threshold:0,rootMargin:'0px 0px 35% 0px'});
/* safety: nothing stays hidden. A fast scroll, a hash jump or a print reveals everything at or above the fold */
addEventListener('scroll',function(){var h=innerHeight*1.4;els.forEach(function(e){if(!e.classList.contains('in')&&e.getBoundingClientRect().top<h)e.classList.add('in')})},{passive:true});
setTimeout(function(){els.forEach(function(e){if(e.getBoundingClientRect().top<innerHeight*1.4)e.classList.add('in')})},1200);
addEventListener('hashchange',function(){els.forEach(function(e){if(e.getBoundingClientRect().top<innerHeight)e.classList.add('in')})});
els.forEach(function(e){io.observe(e)});setTimeout(function(){els.forEach(function(e){var r=e.getBoundingClientRect();if(r.top<innerHeight)e.classList.add('in')})},900)}
/* specular highlight follows the pointer on tilting cards */
function tilt(c){c.style.transformStyle='preserve-3d';c.style.transition='transform .25s ease, box-shadow .25s ease';
c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;c.style.setProperty('--px',(x*100).toFixed(1)+'%');c.style.setProperty('--py',(y*100).toFixed(1)+'%');c.style.transform='perspective(900px) rotateX('+((y-.5)*-6).toFixed(2)+'deg) rotateY('+((x-.5)*6).toFixed(2)+'deg) translateY(-3px)'});
c.addEventListener('pointerleave',function(){c.style.transform=''})}
if(!rm&&fine){document.querySelectorAll('.pv-tilt').forEach(function(c){c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect();c.style.setProperty('--px',((e.clientX-r.left)/r.width*100).toFixed(1)+'%');c.style.setProperty('--py',((e.clientY-r.top)/r.height*100).toFixed(1)+'%')})});
if(dir==='showcase'){document.querySelectorAll('main .pv-grid .q-card,main .pv-loc .q-card,main .pv-seal .item').forEach(function(c){if(!c.classList.contains('pv-tilt')){c.classList.add('pv-tilt');tilt(c)}})}}
/* stage floor and spotlight on the proof band, Showcase */
if(dir==='showcase'){var st=document.getElementById('proof');if(st){st.classList.add('pv-stage');if(!rm&&fine){st.addEventListener('pointermove',function(e){var r=st.getBoundingClientRect();st.style.setProperty('--mx',((e.clientX-r.left)/r.width*100).toFixed(1)+'%');st.style.setProperty('--my',((e.clientY-r.top)/r.height*100).toFixed(1)+'%')})}}}
})();