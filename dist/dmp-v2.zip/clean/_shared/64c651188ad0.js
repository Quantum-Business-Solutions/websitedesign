
(function(){
var d=document;
/* directions switcher: touch toggle, fade away while scrolling */
var sw=d.querySelector('.pv-switch'),tab=sw&&sw.querySelector('.pv-sw-tab');
if(tab){tab.addEventListener('click',function(){var o=sw.classList.toggle('open');tab.setAttribute('aria-expanded',o?'true':'false')});
d.addEventListener('keydown',function(e){if(e.key==='Escape'&&sw.classList.contains('open')){sw.classList.remove('open');tab.setAttribute('aria-expanded','false');tab.focus()}});
d.addEventListener('click',function(e){if(!sw.contains(e.target)){sw.classList.remove('open');tab.setAttribute('aria-expanded','false')}})}
var swm=d.querySelector('.pv-switch-m'),qt=0;
if(swm){addEventListener('scroll',function(){if(swm.open||swm.contains(d.activeElement))return;swm.classList.add('pv-quiet');clearTimeout(qt);qt=setTimeout(function(){swm.classList.remove('pv-quiet')},900)},{passive:true})}
/* carousel: arrow keys work while it is in view and nothing is being typed in */
[].forEach.call(d.querySelectorAll('[data-mo=c3]'),function(root){
var inView=false,st=root.querySelector('.mo-c3-stage');
if('IntersectionObserver' in window){new IntersectionObserver(function(es){inView=es[0].isIntersecting},{threshold:.5}).observe(root)}
d.addEventListener('keydown',function(e){
if(!inView||e.defaultPrevented||e.altKey||e.ctrlKey||e.metaKey)return;
if(e.key!=='ArrowLeft'&&e.key!=='ArrowRight')return;
var a=d.activeElement,t=a&&a.tagName;if(t==='INPUT'||t==='TEXTAREA'||t==='SELECT'||(a&&a.isContentEditable))return;
if(a&&a!==d.body&&st&&st.contains(a))return; /* the stage handles its own keys */
var s=d.getElementById('pv-search');if(s&&!s.hidden)return;
var b=root.querySelector('.mo-c3-btn[data-d="'+(e.key==='ArrowRight'?1:-1)+'"]');if(b){e.preventDefault();b.click()}})});
/* finder: image wells that fail to load drop out, last row stays balanced */
[].forEach.call(d.querySelectorAll('.mo-fc-img img'),function(im){var f=function(){im.parentNode.classList.add('is-ph')};im.addEventListener('error',f);if(im.complete&&im.naturalWidth===0&&im.currentSrc)f()});
[].forEach.call(d.querySelectorAll('.mo-fnd-grid'),function(g){
function bal(){var vis=[].filter.call(g.children,function(c){return !c.hidden&&!c.classList.contains('mo-out')});[].forEach.call(g.children,function(x){x.classList.remove('mo-lc1','mo-lc2a','mo-lc2b','mo-lcs')});
var c=innerWidth>=1025?3:innerWidth>=768?2:1,n=vis.length,r=c>1?n%c:0;
if(c===3){if(r===1)vis[n-1].classList.add('mo-lc1');if(r===2){vis[n-2].classList.add('mo-lc2a');vis[n-1].classList.add('mo-lc2b')}}else if(c===2&&r===1)vis[n-1].classList.add('mo-lcs')}
bal();addEventListener('resize',bal);var w=g.closest('.mo-fnd');if(w)w.addEventListener('click',function(){setTimeout(bal,0);setTimeout(bal,340)})});
/* partner marquee: a visible pause control (WCAG 2.2.2) */
[].forEach.call(d.querySelectorAll('.pv-logos'),function(lg){var tr=lg.querySelector('.pv-logos-track');if(!tr||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
var b=d.createElement('button');b.type='button';b.className='pv-lpp';b.setAttribute('aria-pressed','false');b.textContent='Pause scrolling';lg.insertAdjacentElement('afterend',b);
b.addEventListener('click',function(){var o=lg.classList.toggle('pv-still');b.setAttribute('aria-pressed',o?'true':'false');b.textContent=o?'Resume scrolling':'Pause scrolling'})});
/* mobile menu: aria-expanded, scroll lock, focus trap, Esc closes and restores focus */
var mn=d.querySelector('.q-mnav'),ms=mn&&mn.querySelector('summary');
if(mn&&ms){var sync=function(){var o=mn.open;ms.setAttribute('aria-expanded',o?'true':'false');ms.setAttribute('aria-label',o?'Close menu':'Open menu');var sb=d.getElementById('pv-search');d.documentElement.style.overflow=(o||(sb&&!sb.hidden))?'hidden':''};
sync();mn.addEventListener('toggle',sync);
d.addEventListener('keydown',function(e){if(!mn.open)return;
if(e.key==='Escape'){e.preventDefault();mn.open=false;ms.focus()}
else if(e.key==='Tab'){var f=[ms].concat([].slice.call(mn.querySelectorAll('.q-mnav-panel a[href],.q-mnav-panel button,.q-mnav-panel summary'))).filter(function(n){return n.offsetParent!==null||n===ms});var i=f.indexOf(d.activeElement);
if(i<0){e.preventDefault();f[0].focus()}else if(e.shiftKey&&i===0){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&i===f.length-1){e.preventDefault();f[0].focus()}}});
addEventListener('resize',function(){if(mn.open&&innerWidth>1024){mn.open=false}})}
/* search */
var box=d.getElementById('pv-search');if(!box)return;
var inp=box.querySelector('input'),ul=box.querySelector('.pv-search-r'),hint=box.querySelector('.pv-search-h'),root=box.getAttribute('data-root')||'',idx=null,loading=false,last=null,sel=-1,res=[];
var q=[];function load(cb){if(idx)return cb();q.push(cb);if(loading)return;loading=true;
fetch(root+'search-index.json').then(function(r){return r.json()}).then(function(j){idx=j;loading=false;var f=q;q=[];f.forEach(function(x){x()})}).catch(function(){loading=false;hint.textContent='The search index could not be loaded. It is generated with the build and needs the site served over http.'})}
function open(){last=d.activeElement;if(mn&&mn.open){mn.open=false}box.hidden=false;d.documentElement.style.overflow='hidden';inp.value='';ul.innerHTML='';hint.textContent='Type to search. Try XR550, UL 864 or dealer portal. Arrow keys to move, Enter to open.';load(function(){});inp.focus();setTimeout(function(){inp.focus()},0)}
function close(){inp.setAttribute('aria-expanded','false');inp.removeAttribute('aria-activedescendant');box.hidden=true;d.documentElement.style.overflow='';if(last&&last.focus)last.focus()}
function esc(s){return s.replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function terms(q){return q.toLowerCase().split(/[^a-z0-9\u00e9]+/).filter(function(x){return x.length>0})}
function rx(w){return new RegExp('\\b'+w.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+(w.length<=3?'\\b':''),'i')}
function score(r,ts,q){var t=r.t.toLowerCase(),dd=(r.d||'').toLowerCase(),b=(r.b||'').toLowerCase(),k=(r.k||'').toLowerCase(),s=0;
if(t.indexOf(q)>-1)s+=14;if(k.indexOf(q)>-1)s+=8;if(b.indexOf(q)>-1)s+=6;
for(var i=0;i<ts.length;i++){var w=ts[i],R=rx(w),h=0;
if(R.test(t))h+=10;if(R.test(k))h+=6;if(R.test(dd))h+=4;
var m=b.match(new RegExp(R.source,'gi'));if(m)h+=Math.min(5,m.length);
if(!h)return 0;s+=h}
return s}
function snip(r,ts){var txt=r.b||r.d||'',p=-1;for(var i=0;i<ts.length&&p<0;i++)p=txt.search(rx(ts[i]));
var s=p<0?0:Math.max(0,p-50),out=(s?'\u2026':'')+txt.slice(s,s+150)+(txt.length>s+150?'\u2026':'');var h=esc(out);
ts.forEach(function(w){if(w.length>1)h=h.replace(new RegExp('('+rx(w).source+'[a-z0-9]*)','ig'),'<mark>$1</mark>')});return h}
function show(){var q=inp.value.trim();sel=-1;if(!q){ul.innerHTML='';hint.textContent='Type to search. Try XR550, UL 864 or dealer portal. Arrow keys to move, Enter to open.';return}
if(!idx){hint.textContent='Loading the index...';return}
var ts=terms(q),ql=q.toLowerCase();
res=idx.map(function(r){return{r:r,s:score(r,ts,ql)}}).filter(function(x){return x.s>0}).sort(function(a,b){return b.s-a.s}).slice(0,8);
ul.innerHTML=res.map(function(x,i){return '<li role="presentation"><a role="option" id="pv-sr-'+i+'" href="'+root+esc(x.r.u)+'"><b>'+esc(x.r.t)+'</b><small>'+esc(x.r.u)+'</small><p>'+snip(x.r,ts)+'</p></a></li>'}).join('');
hint.textContent=res.length?res.length+(res.length===1?' result':' results')+'. Arrow keys to move, Enter to open.':'No pages match "'+q+'". Try a part number such as XR550, or a word like dealer.';
if(res.length)mark(0)}
function mark(i){var as=ul.querySelectorAll('a');if(!as.length)return;sel=(i+as.length)%as.length;[].forEach.call(as,function(a,j){a.setAttribute('aria-selected',j===sel?'true':'false')});as[sel].scrollIntoView({block:'nearest'});inp.setAttribute('aria-activedescendant','pv-sr-'+sel)}
inp.addEventListener('input',function(){load(show);show();inp.setAttribute('aria-expanded',ul.children.length?'true':'false');if(!ul.children.length)inp.removeAttribute('aria-activedescendant')});
box.addEventListener('keydown',function(e){
if(e.key==='Escape'){e.preventDefault();close()}
else if(e.key==='ArrowDown'){e.preventDefault();mark(sel+1)}
else if(e.key==='ArrowUp'){e.preventDefault();mark(sel-1)}
else if(e.key==='Enter'){var a=ul.querySelectorAll('a')[Math.max(sel,0)];if(a){e.preventDefault();location.href=a.href}}
else if(e.key==='Tab'){var f=[].slice.call(box.querySelectorAll('input,button,a')).filter(function(n){return n.offsetParent!==null});if(!f.length)return;var i=f.indexOf(d.activeElement);if(e.shiftKey&&i<=0){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&i===f.length-1){e.preventDefault();f[0].focus()}}});
box.addEventListener('mousedown',function(e){if(e.target===box)close()});
box.querySelector('.pv-search-x').addEventListener('click',close);
[].forEach.call(d.querySelectorAll('[data-pv-search]'),function(b){b.addEventListener('click',function(){var mn=d.querySelector('.q-mnav');if(mn&&mn.open)mn.open=false;open()})});
d.addEventListener('keydown',function(e){if(e.key!=='/'||e.ctrlKey||e.metaKey||e.altKey||!box.hidden)return;var a=d.activeElement,t=a&&a.tagName;if(t==='INPUT'||t==='TEXTAREA'||t==='SELECT'||(a&&a.isContentEditable))return;e.preventDefault();open()});
})();
