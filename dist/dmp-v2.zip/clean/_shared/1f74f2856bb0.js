(function(){
var d=document,rm=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(pointer:fine) and (min-width:1025px)').matches,io='IntersectionObserver' in window;
function $$(s,r){return [].slice.call((r||d).querySelectorAll(s))}
var hd=d.querySelector('.q-header');
function hh(){if(hd)d.documentElement.style.setProperty('--pp-hdr',Math.round(hd.getBoundingClientRect().height)+'px')}
hh();addEventListener('resize',hh);addEventListener('load',hh);var hq=false;addEventListener('scroll',function(){if(!hq){hq=true;requestAnimationFrame(function(){hq=false;hh()})}},{passive:true});
function watch(els,cb,th){if(!els.length)return;if(!io||rm){els.forEach(function(e){cb(e)});return}
 var o=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting||x.boundingClientRect.top<0){o.unobserve(x.target);cb(x.target)}})},{threshold:th||.25,rootMargin:'0px 0px -6% 0px'});
 els.forEach(function(e){o.observe(e)});
 setTimeout(function(){els.forEach(function(e){var r=e.getBoundingClientRect();if(r.top<-200)cb(e)})},1400)}
/* flow and connect: arm, then light on view */
watch($$('.pp-flow'),function(e){e.classList.add('go')},.3);
watch($$('.pp-con'),function(e){e.classList.add('go')},.3);
/* proof numerals: fill, and count up */
var pr=$$('.pp-pr');
pr.forEach(function(e){var n=e.querySelector('[data-count]');if(n&&io&&!rm){n.setAttribute('data-final',n.textContent);n.textContent='0'}});
watch(pr,function(e,i){e.classList.add('in');var n=e.querySelector('[data-count]');if(!n||rm||!io){if(n&&n.getAttribute('data-final'))n.textContent=n.getAttribute('data-final');return}
 var to=+n.getAttribute('data-count'),t0=null;function st(t){if(t0===null)t0=t;var p=Math.min(1,(t-t0)/1400),v=Math.round(to*(1-Math.pow(1-p,3)));n.textContent=String(v);if(p<1)requestAnimationFrame(st);else n.textContent=n.getAttribute('data-final')}
 requestAnimationFrame(st)},.35);
/* doors: tilt */
if(fine&&!rm){$$('.pp-door').forEach(function(c){c.addEventListener('pointermove',function(e){var b=c.getBoundingClientRect(),x=(e.clientX-b.left)/b.width-.5,y=(e.clientY-b.top)/b.height-.5;c.style.setProperty('--ry',(x*7).toFixed(2)+'deg');c.style.setProperty('--rx',(-y*6).toFixed(2)+'deg')});c.addEventListener('pointerleave',function(){c.style.setProperty('--ry','0deg');c.style.setProperty('--rx','0deg')})})}
/* subnav scroll spy */
$$('.pp-subnav').forEach(function(nav){var links=$$('a',nav),tg=links.map(function(a){return d.getElementById((a.getAttribute('href')||'').replace('#',''))}),tick=false;
 function spy(){tick=false;var line=(parseInt(getComputedStyle(d.documentElement).getPropertyValue('--pp-hdr'))||81)+nav.offsetHeight+60,cur=-1;
  tg.forEach(function(t,i){if(t&&t.getBoundingClientRect().top<=line)cur=i});
  links.forEach(function(a,i){a.classList.toggle('on',i===cur);if(i===cur)a.setAttribute('aria-current','true');else a.removeAttribute('aria-current')});
  var on=links[cur],ul=on&&on.closest('ul');if(on&&ul&&ul.scrollWidth>ul.clientWidth){var l=on.offsetLeft-ul.clientWidth/2+on.offsetWidth/2;ul.scrollLeft=l}}
 addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(spy)}},{passive:true});spy()});
/* panel picker */
$$('.pp-pk').forEach(function(root){var cfg;try{cfg=JSON.parse(root.getAttribute('data-pp'))}catch(e){return}
 var qs=$$('.pp-q',root),cards=$$('.pp-r',root),box=root.querySelector('.pp-rs'),live=root.querySelector('.pp-live'),st=(cfg.start||[]).slice();
 function match(){for(var i=0;i<cfg.rules.length;i++){var r=cfg.rules[i],ok=true;for(var q=0;q<st.length;q++){var w=r.when[q];if(w&&w.indexOf(st[q])<0){ok=false;break}}if(ok)return r}return cfg.rules[cfg.rules.length-1]}
 function paint(anim){var r=match(),first=null;cards.forEach(function(c){c.hidden=true});
  r.res.forEach(function(s){var c=root.querySelector('.pp-r[data-slug="'+s+'"]');if(!c)return;c.hidden=false;box.appendChild(c);var w=c.querySelector('.pp-why');if(w&&r.why&&r.why[s])w.textContent=r.why[s];if(!first)first=c});
  if(anim&&!rm){box.classList.remove('swap');void box.offsetWidth;box.classList.add('swap')}
  if(live&&first){var h=first.querySelector('h3');live.textContent=(cfg.say||'Suggested: ')+(h?h.textContent:'')}}
 qs.forEach(function(q,qi){$$('.pp-chip',q).forEach(function(b,bi){b.setAttribute('aria-pressed',bi===st[qi]?'true':'false');b.addEventListener('click',function(){st[qi]=bi;$$('.pp-chip',q).forEach(function(x,k){x.setAttribute('aria-pressed',k===bi?'true':'false')});paint(true)})})});
 paint(false)});
/* buy bar */
$$('.pp-bb').forEach(function(bar){var tg=d.getElementById(bar.getAttribute('data-target')||'pstage');if(!tg)return;
 function set(on){bar.classList.toggle('on',on)}
 if(io){new IntersectionObserver(function(es){var e=es[0];set(!e.isIntersecting&&e.boundingClientRect.top<0)},{threshold:0}).observe(tg)}else{addEventListener('scroll',function(){set(tg.getBoundingClientRect().bottom<0)},{passive:true})}});
})();