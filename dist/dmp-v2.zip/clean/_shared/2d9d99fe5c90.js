
(function(){
var d=document,p=location.pathname,m=p.match(/\/(showcase|clean|press)\/(.*)$/);
var up=m?new Array((m[2].match(/\//g)||[]).length+2).join('../'):'';
var hub=(m?up:'')+'index.html';
try{if(sessionStorage.getItem('pv-notice')==='0'){}else if(!d.querySelector('.pv-notice')&&m){
var n=d.createElement('div');n.className='pv-notice';n.setAttribute('role','note');
n.innerHTML='<span><b>Design preview.</b> Forms, the dealer portal and sign-in are mock-ups and do not send anything yet.</span> <a href="'+hub+'#confirm">What is real and what DMP confirms</a><button type="button" aria-label="Dismiss this notice">&times;</button>';
d.body.insertBefore(n,d.body.firstChild);
n.querySelector('button').addEventListener('click',function(){n.remove();try{sessionStorage.setItem('pv-notice','0')}catch(e){}});}}catch(e){}
[].forEach.call(d.querySelectorAll('form.q-form'),function(f){
f.addEventListener('submit',function(e){
e.preventDefault();
[].forEach.call(f.querySelectorAll('.pv-fe,.pv-fn'),function(x){x.remove()});
var bad=null;
[].forEach.call(f.querySelectorAll('input,select,textarea'),function(i){
i.removeAttribute('aria-invalid');
var t=(i.type||'').toLowerCase();if(t==='submit'||t==='hidden'||t==='checkbox'||t==='radio')return;
var v=(i.value||'').trim(),isEmail=t==='email'||/email/i.test(i.id+i.name);
var ok=v.length>0;if(ok&&isEmail)ok=/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v);
if(i.required||isEmail||/name|first|last/i.test(i.id+i.name)){if(!ok){i.setAttribute('aria-invalid','true');if(!bad)bad=i;}}
});
var sub=f.querySelector('[type=submit]');
if(bad){var er=d.createElement('p');er.className='pv-fe';er.setAttribute('role','alert');er.textContent='Please fill in the highlighted fields (a name and a valid email).';(sub&&sub.parentNode===f?f:f).appendChild(er);bad.focus();return;}
var ok=d.createElement('div');ok.className='pv-fn';ok.setAttribute('role','status');
ok.innerHTML='<b>Preview only. This form did not send.</b>On the live site this goes to DMP’s team. For now, call 877-757-4367 (8 a.m. to 5 p.m. Central) or email InsideSales@DMP.com.';
f.appendChild(ok);
});
});
})();
