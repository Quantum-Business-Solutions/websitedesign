
(function(){
var d=document,RM=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
function $(s,r){return (r||d).querySelector(s)}
function mk(t,c,h){var e=d.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}

/* ---------- assessment ---------- */
var as=$('[data-pp3-assess]');
if(as){try{(function(){
var cfg=JSON.parse($('script[type="application/json"]',as).textContent),Q=cfg.questions,A=cfg.areas,n=Q.length,i=0,ans=[];
var js=$('.pp3-as-js',as),nojs=$('.pp3-as-nojs',as);js.hidden=false;nojs.hidden=true;
var step=$('.pp3-step',as),res=$('.pp3-res',as),bar=$('.pp3-prog i',as),pb=$('.pp3-prog',as),ptxt=$('.pp3-ptxt',as),ppct=$('.pp3-ppct',as),qa=$('.pp3-qarea',as),qt=$('.pp3-qtext',as),hint=$('.pp3-hint',as),back=$('.pp3-back',step),opts=[].slice.call(step.querySelectorAll('.pp3-opt'));
function show(foc){
 qa.textContent=A[Q[i].area].title;qt.textContent=Q[i].q;hint.textContent=Q[i].hint;
 ptxt.textContent='Question '+(i+1)+' of '+n;var done=Math.round(i/n*100);ppct.textContent=done+'% done';bar.style.width=(i/n*100)+'%';pb.setAttribute('aria-valuenow',i);
 opts.forEach(function(o){o.setAttribute('aria-pressed',String(ans[i]!=null&&String(ans[i])===o.getAttribute('data-v')))});
 back.disabled=i===0;if(foc)qt.focus();
}
opts.forEach(function(o){o.addEventListener('click',function(){ans[i]=+o.getAttribute('data-v');
 opts.forEach(function(x){x.setAttribute('aria-pressed',String(x===o))});
 if(i<n-1){i++;show(true)}else{bar.style.width='100%';results()}})});
back.addEventListener('click',function(){if(i>0){i--;show(true)}});
function results(){
 step.hidden=true;res.hidden=false;
 var tot=0,per={};Q.forEach(function(q,k){tot+=ans[k];var p=per[q.area]||(per[q.area]={s:0,m:0});p.s+=ans[k];p.m+=2});
 var pct=Math.round(tot/(2*n)*100);
 var band=pct>=75?'Broad coverage':pct>=40?'Some gaps worth a look':'Plenty of room to look';
 $('.pp3-rt',res).textContent=band;
 $('.pp3-rp',res).textContent='You answered yes to '+ans.filter(function(a){return a===2}).length+' of '+n+' questions, not sure to '+ans.filter(function(a){return a===1}).length+' and no to '+ans.filter(function(a){return a===0}).length+'. The three areas below scored lowest, so they are the best places to start.';
 var keys=Object.keys(A);keys.sort(function(a,b){var x=per[a]?per[a].s/per[a].m:2,y=per[b]?per[b].s/per[b].m:2;return x-y});
 $('.pp3-areas',res).innerHTML=Object.keys(per).map(function(k){var v=Math.round(per[k].s/per[k].m*100);return '<li><span>'+esc(A[k].title)+'</span><span class="bar"><i style="width:'+v+'%"></i></span><span class="v">'+v+'%</span></li>'}).join('');
 $('.pp3-recs',res).innerHTML=keys.filter(function(k){return per[k]}).slice(0,3).map(function(k,j){var a=A[k];return '<li class="pp3-rec"><span class="n" aria-hidden="true">'+(j+1)+'</span><h4>'+esc(a.title)+'</h4><p>'+esc(a.text)+'</p><span class="links">'+a.links.map(function(l){return '<a href="'+esc(l[1])+'">'+esc(l[0])+'</a>'}).join('')+'</span></li>'}).join('');
 var c=$('.pp3-ring-c',res),pe=$('.pp3-pct',res),C=540.35;
 if(RM){c.style.strokeDashoffset=String(C*(1-pct/100));pe.textContent=pct+'%'}
 else{c.getBoundingClientRect();c.style.strokeDashoffset=String(C*(1-pct/100));var t0=null;(function f(t){if(t0==null)t0=t;var p=Math.min(1,(t-t0)/1000);pe.textContent=Math.round(pct*(1-Math.pow(1-p,3)))+'%';if(p<1)requestAnimationFrame(f)})(performance.now())}
 var rt=$('.pp3-rt',res);rt.focus();res.scrollIntoView({block:'nearest'});
}
function back2(){res.hidden=true;step.hidden=false;show(true)}
$('.pp3-redo',res).addEventListener('click',function(){ans=[];i=0;$('.pp3-ring-c',res).style.strokeDashoffset='540.35';back2()});
$('.pp3-edit',res).addEventListener('click',function(){i=n-1;back2()});
show(false);
})()}catch(e){}}

/* ---------- estimator ---------- */
var cc=$('[data-pp3-calc]');
if(cc){(function(){
var f={calls:$('#pc-calls'),cost:$('#pc-cost'),share:$('#pc-share'),rate:$('#pc-rate'),hrs:$('#pc-hrs')};
var out={empty:$('[data-empty]',cc),res:$('[data-result]',cc),month:$('[data-month]',cc),year:$('[data-year]',cc),rc:$('[data-rc]',cc),cc:$('[data-cc]',cc),hf:$('[data-hf]',cc),tc:$('[data-tc]',cc)};
var shown={month:0,year:0},last=null;
function num(v){v=String(v).replace(/[$,%\s]/g,'');if(v==='')return null;var x=Number(v);return isFinite(x)?x:NaN}
var usd=function(x){return '$'+Math.round(x).toLocaleString('en-US')};
function setErr(k,m){var e=$('#pc-'+k+'-e');e.textContent=m||'';f[k].setAttribute('aria-invalid',m?'true':'false')}
function anim(el,key,to,fmt){var from=shown[key];shown[key]=to;if(RM||from===to){el.textContent=fmt(to);return}
 var t0=null;(function s(t){if(t0==null)t0=t;var p=Math.min(1,(t-t0)/700),e=1-Math.pow(1-p,3);el.textContent=fmt(from+(to-from)*e);if(p<1&&shown[key]===to)requestAnimationFrame(s);else if(shown[key]===to)el.textContent=fmt(to)})(performance.now())}
function calc(){
 var v={},bad=false;
 ['calls','cost','share','rate','hrs'].forEach(function(k){var x=num(f[k].value);v[k]=x;var m='';if(x!==null&&(isNaN(x)||x<0))m='Enter a number, zero or more.';else if(k==='share'&&x!==null&&x>100)m='Enter a percent from 0 to 100.';setErr(k,m);if(m)bad=true});
 var hasCost=(v.cost||0)>0||((v.rate||0)>0&&(v.hrs||0)>0);
 if(bad||v.calls===null||v.share===null||!hasCost){out.res.hidden=true;out.empty.hidden=false;last=null;shown.month=0;shown.year=0;return}
 var rc=v.calls*v.share/100,cs=rc*(v.cost||0),hf=rc*(v.hrs||0),tc=hf*(v.rate||0),m=cs+tc;
 out.empty.hidden=true;out.res.hidden=false;
 anim(out.month,'month',m,usd);anim(out.year,'year',m*12,usd);
 out.rc.textContent=(Math.round(rc*10)/10).toLocaleString('en-US');out.cc.textContent=usd(cs);out.hf.textContent=(Math.round(hf*10)/10).toLocaleString('en-US');out.tc.textContent=usd(tc);
 last={v:v,rc:rc,cs:cs,hf:hf,tc:tc,m:m};
}
Object.keys(f).forEach(function(k){f[k].addEventListener('input',calc)});
var cb=$('[data-copy]',cc),cm=$('[data-copied]',cc);
cb.addEventListener('click',function(){if(!last)return;var v=last.v;
 var t=['Service-call savings estimate (my own numbers)','Service calls per month: '+v.calls,'Average cost per call: '+usd(v.cost||0),'Share handled remotely: '+v.share+'%','Technician hourly cost: '+usd(v.rate||0),'Technician hours per call: '+(v.hrs||0),'',
 'Calls handled remotely per month: '+(Math.round(last.rc*10)/10),'Estimated monthly savings: '+usd(last.m),'Estimated yearly savings: '+usd(last.m*12),'',
 'Formula: calls x share x (cost per call + hours per call x hourly cost); yearly = monthly x 12.','Your numbers, your math. Not a DMP guarantee.'].join('\n');
 function ok(){cm.textContent='Copied to your clipboard.'}
 function fb(){var ta=d.createElement('textarea');ta.value=t;ta.setAttribute('readonly','');ta.style.cssText='position:fixed;left:-9999px';d.body.appendChild(ta);ta.select();try{d.execCommand('copy')?ok():cm.textContent='Select and copy the numbers above.'}catch(e){cm.textContent='Select and copy the numbers above.'}ta.remove()}
 if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(ok,fb)}else fb();
});
})()}

/* ---------- gate ---------- */
var g=$('[data-pp3-gate]');
if(g){(function(){
var form=$('[data-gate-form]',g),th=$('[data-gate-thanks]',g),er=$('[data-gate-err]',g),mail=d.querySelector('[data-gate-mail]'),to=d.querySelector('[data-gate-to]');
form.addEventListener('submit',function(e){e.preventDefault();var n=$('#pg-n').value.trim(),m=$('#pg-e').value.trim();
 if(!n||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(m)){er.textContent='Please add your name and a valid work email.';(n?$('#pg-e'):$('#pg-n')).focus();return}
 er.textContent='';form.hidden=true;th.hidden=false;$('[data-gate-msg]',g).textContent='Preview only: nothing was sent. On the live site the playbook would be emailed to '+m+'. The mock email further down shows what it would look like.';
 if(to)to.textContent=m;if(mail)mail.classList.add('sent');th.focus()});
$('[data-gate-reset]',g).addEventListener('click',function(){th.hidden=true;form.hidden=false;if(mail)mail.classList.remove('sent');if(to)to.textContent='your work email';$('#pg-e').focus()});
})()}

/* ---------- consent banner (preview) ---------- */
(function(){
if(top!==self)return;var KEY='pp3-consent',v=null;
try{v=localStorage.getItem(KEY)}catch(e){}
if(v)return;
var b=mk('div','pp3-cc');b.setAttribute('role','region');b.setAttribute('aria-label','Cookie consent (preview)');
b.innerHTML='<p class="pre">Preview of the consent banner; the live site uses HubSpot’s consent tool.</p><h2>Cookies on this site</h2><p class="txt">Essential cookies keep the site working. Optional analytics and marketing cookies are only used if you allow them. Wording to be confirmed.</p><div class="pp3-prefs" hidden><fieldset><legend class="sr-only" style="position:absolute;left:-9999px">Cookie preferences</legend><label><input type="checkbox" checked disabled> Essential, always on</label><label><input type="checkbox" data-k="analytics"> Analytics</label><label><input type="checkbox" data-k="marketing"> Marketing</label></fieldset><div class="row"><button type="button" class="pri" data-a="save">Save preferences</button></div></div><div class="row pp3-main"><button type="button" class="pri" data-a="all">Accept all</button><button type="button" data-a="none">Reject non-essential</button><button type="button" data-a="prefs" aria-expanded="false">Preferences</button></div>';
function done(c){var o={v:1,choice:c.choice,analytics:!!c.analytics,marketing:!!c.marketing};try{localStorage.setItem(KEY,JSON.stringify(o))}catch(e){}b.remove()}
b.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('button[data-a]');if(!a)return;var k=a.getAttribute('data-a');
 if(k==='all')done({choice:'all',analytics:1,marketing:1});
 else if(k==='none')done({choice:'essential'});
 else if(k==='prefs'){var p=$('.pp3-prefs',b);p.hidden=!p.hidden;a.setAttribute('aria-expanded',String(!p.hidden));b.classList.toggle('open',!p.hidden);if(!p.hidden)$('input[data-k]',b).focus()}
 else if(k==='save')done({choice:'custom',analytics:$('input[data-k=analytics]',b).checked,marketing:$('input[data-k=marketing]',b).checked})});
d.body.appendChild(b);
})();
})();
