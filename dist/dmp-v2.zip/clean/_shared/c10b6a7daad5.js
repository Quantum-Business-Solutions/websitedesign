(function(){
var rm=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(pointer:fine)').matches,desk=function(){return matchMedia('(min-width:768px)').matches};
function $(r,s){return r.querySelector(s)}function $$(r,s){return [].slice.call(r.querySelectorAll(s))}
/* scroll progress bar */
if(!rm&&!document.querySelector('.mo-progress')){var pb=document.createElement('div');pb.className='mo-progress';pb.setAttribute('aria-hidden','true');document.body.appendChild(pb);var pr=0;
function pu(){pr=0;var h=document.documentElement.scrollHeight-innerHeight;pb.style.transform='scaleX('+(h>0?Math.min(1,scrollY/h):0).toFixed(4)+')'}
addEventListener('scroll',function(){if(!pr)pr=requestAnimationFrame(pu)},{passive:true});addEventListener('resize',pu);pu()}
/* magnetic primary buttons */
if(!rm&&fine){$$(document,'main .q-btn').forEach(function(b){if(b.classList.contains('mo-signin'))return;b.addEventListener('pointermove',function(e){var r=b.getBoundingClientRect(),x=(e.clientX-r.left-r.width/2)/r.width,y=(e.clientY-r.top-r.height/2)/r.height;b.style.transition='transform .15s ease-out';b.style.transform='translate('+(x*10).toFixed(1)+'px,'+(y*8).toFixed(1)+'px)'});b.addEventListener('pointerleave',function(){b.style.transition='transform .35s cubic-bezier(.2,.7,.2,1)';b.style.transform=''})})}

/* ---- finder ---- */
$$(document,'[data-mo=finder]').forEach(function(root){
var cards=$$(root,'.mo-fc'),cnt=$(root,'[data-count]'),unit=$(root,'[data-unit]'),empty=$(root,'.mo-fnd-empty'),sel={b:'all',n:'all'},first=true;
function has(c,att,k){if(k==='all')return true;var v=(c.getAttribute(att)||'').split(' ').filter(Boolean);return !v.length||v.indexOf(k)>-1}
function apply(){var shown=0;cards.forEach(function(c){var ok=has(c,'data-b',sel.b)&&has(c,'data-n',sel.n);if(ok)shown++;
if(rm||first){c.hidden=!ok;c.classList.remove('mo-out','mo-pre');return}
if(ok&&c.hidden){c.hidden=false;c.classList.remove('mo-out');c.classList.add('mo-pre');void c.offsetWidth;c.classList.remove('mo-pre')}
else if(ok){c.classList.remove('mo-out')}
else if(!c.hidden&&!c.classList.contains('mo-out')){c.classList.add('mo-out');(function(c){setTimeout(function(){if(c.classList.contains('mo-out'))c.hidden=true},280)})(c)}});
cnt.textContent=shown;unit.textContent=shown===1?'product':'products';empty.hidden=shown>0}
$$(root,'.mo-fnd-row').forEach(function(row){var kind=row.getAttribute('data-kind');$$(row,'.mo-chip').forEach(function(ch){ch.addEventListener('click',function(){sel[kind]=ch.getAttribute('data-k');$$(row,'.mo-chip').forEach(function(o){o.setAttribute('aria-pressed',o===ch?'true':'false')});apply()})})});
var rs=$(root,'.mo-reset');if(rs)rs.addEventListener('click',function(){sel={b:'all',n:'all'};$$(root,'.mo-chip').forEach(function(o){o.setAttribute('aria-pressed',o.getAttribute('data-k')==='all'?'true':'false')});apply()});
apply();first=false});

/* ---- 3D coverflow ---- */
$$(document,'[data-mo=c3]').forEach(function(root){
var stage=$(root,'.mo-c3-stage'),cards=$$(root,'.mo-c3-card'),dots=$$(root,'.mo-c3-dot'),n=cards.length,cur=0,nm=$(root,'[data-n]'),bl=$(root,'[data-b]'),go=$(root,'[data-go]');
root.classList.add('is-3d');
function lay(){var w=stage.clientWidth,cw=cards[0].offsetWidth,small=w<640,step=small?cw*.5:Math.min(cw*.72,w/4.2),ang=small?38:44,dz=small?120:170;
cards.forEach(function(c,i){var o=i-cur;if(o>n/2)o-=n;if(o<-n/2)o+=n;var a=Math.abs(o),vis=a<=(small?1:3),x=o*step+(o>0?cw*.1:o<0?-cw*.1:0)*(small?0:1);
c.style.transform='translate(-50%,-50%) translateX('+x.toFixed(1)+'px) translateZ('+(a===0?60:-a*dz*.55).toFixed(0)+'px) rotateY('+(o===0?0:(o>0?-ang:ang))+'deg) scale('+(a===0?1:Math.max(.72,1-a*.08)).toFixed(3)+')';
c.style.zIndex=String(50-a);c.style.opacity=vis?'1':'0';c.style.pointerEvents=vis?'auto':'none';c.classList.toggle('is-act',o===0);
var lk=$(c,'a');lk.tabIndex=o===0?0:-1;lk.setAttribute('aria-hidden',o===0?'false':'true');c.setAttribute('aria-label',(i+1)+' of '+n)});
dots.forEach(function(d,i){if(i===cur)d.setAttribute('aria-current','true');else d.removeAttribute('aria-current')});
var act=$(cards[cur],'a');nm.textContent=$(act,'.mo-c3-n').textContent;bl.textContent=act.getAttribute('data-blurb')||'';go.setAttribute('href',act.getAttribute('href'))}
function to(i){cur=(i%n+n)%n;lay()}
$$(root,'.mo-c3-btn').forEach(function(b){b.addEventListener('click',function(){to(cur+ +b.getAttribute('data-d'))})});
dots.forEach(function(d,i){d.addEventListener('click',function(){to(i)})});
stage.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){e.preventDefault();to(cur+1)}else if(e.key==='ArrowLeft'){e.preventDefault();to(cur-1)}else if(e.key==='Home'){e.preventDefault();to(0)}else if(e.key==='End'){e.preventDefault();to(n-1)}});
var sx=0,sc=0,drag=false,moved=false,id=null;
stage.addEventListener('pointerdown',function(e){if(e.button>0)return;sx=e.clientX;sc=cur;drag=true;moved=false;id=e.pointerId});
stage.addEventListener('pointermove',function(e){if(drag){var dx=e.clientX-sx;if(Math.abs(dx)>6&&!moved){moved=true;stage.classList.add('is-drag');try{stage.setPointerCapture(id)}catch(x){}}
if(moved){var cw=cards[0].offsetWidth*.6;var k=Math.round(-dx/cw);if(sc+k!==cur)to(sc+k)}return}
if(rm||!fine)return;var a=$(cards[cur],'.mo-c3-in'),r=a.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;if(Math.abs(x)<.9&&Math.abs(y)<.9)a.style.transform='rotateX('+(-y*12).toFixed(1)+'deg) rotateY('+(x*14).toFixed(1)+'deg)'});
function end(){if(!drag)return;drag=false;stage.classList.remove('is-drag');setTimeout(function(){moved=false},0)}
stage.addEventListener('pointerup',end);stage.addEventListener('pointercancel',end);
stage.addEventListener('pointerleave',function(){cards.forEach(function(c){$(c,'.mo-c3-in').style.transform=''})});
cards.forEach(function(c,i){$(c,'a').addEventListener('click',function(e){if(moved){e.preventDefault();return}if(i!==cur){e.preventDefault();to(i)}})});
addEventListener('resize',lay);lay()});

/* ---- portal ---- */
$$(document,'[data-mo=portal]').forEach(function(root){
var scr=$(root,'.mo-screen'),win=$(root,'.mo-win'),dash=$(root,'[data-dash]'),inb=$(root,'[data-signin]'),out=$(root,'[data-out]');
$$(root,'.mo-pt').forEach(function(t,i){t.style.setProperty('--i',i)});
function setIn(v){scr.classList.toggle('is-in',v);dash.setAttribute('aria-hidden',v?'false':'true');out.tabIndex=v?0:-1;if(v)setTimeout(function(){out.focus({preventScroll:true})},rm?0:450);else inb.focus({preventScroll:true})}
inb.addEventListener('click',function(){setIn(true)});out.addEventListener('click',function(){setIn(false)});
if(!rm&&fine){var raf=0;function tilt(){raf=0;var r=root.getBoundingClientRect(),c=(r.top+r.height/2-innerHeight/2)/innerHeight;c=Math.max(-1,Math.min(1,c));win.style.setProperty('--rx',(c*6).toFixed(2)+'deg');win.style.setProperty('--ry',(c*-3).toFixed(2)+'deg');win.style.setProperty('--ty',(c*14).toFixed(1)+'px')}
addEventListener('scroll',function(){if(!raf)raf=requestAnimationFrame(tilt)},{passive:true});tilt()}});

/* ---- network ---- */
$$(document,'[data-mo=network]').forEach(function(root){
var nds=$$(root,'.mo-nd'),lns=$$(root,'.mo-ln'),pin=-1;
function set(i){nds.forEach(function(d,j){var on=j===i;d.classList.toggle('on',on);$(d,'.mo-nb').setAttribute('aria-expanded',on?'true':'false')});lns.forEach(function(l,j){l.classList.toggle('on',j===i)})}
nds.forEach(function(d,i){var b=$(d,'.mo-nb');
d.addEventListener('pointerenter',function(e){if(e.pointerType==='mouse'&&desk())set(i)});
d.addEventListener('pointerleave',function(e){if(e.pointerType==='mouse'&&desk()&&pin!==i)set(pin)});
b.addEventListener('focus',function(){if(desk())set(i)});
b.addEventListener('blur',function(){if(desk()&&pin!==i)setTimeout(function(){if(!root.contains(document.activeElement)||document.activeElement===document.body)set(pin)},0)});
b.addEventListener('click',function(){if(!desk())return;pin=pin===i?-1:i;set(pin)})});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){pin=-1;set(-1)}});
document.addEventListener('click',function(e){if(!root.contains(e.target)){pin=-1;set(-1)}})});

/* ---- stats3d ---- */
$$(document,'[data-mo=stats3d]').forEach(function(root){
var cs=$$(root,'.mo-sc');
if(!rm&&'IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;io.unobserve(e.target);var el=e.target,txt=el.textContent.trim();if(txt.indexOf('/')>-1)return;var m=txt.match(/^([^0-9]*)([0-9][0-9,]*)(\.[0-9]+)?(.*)$/);if(!m)return;var pre=m[1],dec=m[3]||'',suf=m[4],comma=m[2].indexOf(',')>-1,target=parseFloat(m[2].replace(/,/g,'')+dec),pl=dec?dec.length-1:0,t0=null;
function f(v){var s=v.toFixed(pl);if(comma){var p=s.split('.');p[0]=p[0].replace(/\B(?=(\d{3})+(?!\d))/g,',');s=p.join('.')}return pre+s+suf}
function st(ts){if(t0===null)t0=ts;var k=Math.min(1,(ts-t0)/1500);k=1-Math.pow(1-k,3);el.textContent=f(target*k);if(k<1)requestAnimationFrame(st);else el.textContent=txt}el.textContent=f(0);requestAnimationFrame(st)})},{threshold:.5});
$$(root,'[data-num]').forEach(function(b){io.observe(b)})}
if(!rm&&fine){cs.forEach(function(c){var a=$(c,'.mo-sc-in');c.addEventListener('pointermove',function(e){var r=a.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;a.style.setProperty('--rx',((.5-y)*14).toFixed(1)+'deg');a.style.setProperty('--ry',((x-.5)*16).toFixed(1)+'deg');a.style.setProperty('--px',(x*100).toFixed(0)+'%');a.style.setProperty('--py2',(y*100).toFixed(0)+'%')});c.addEventListener('pointerleave',function(){a.style.setProperty('--rx','0deg');a.style.setProperty('--ry','0deg')})})}
if(!rm&&desk()){var raf=0;function par(){raf=0;var r=root.getBoundingClientRect(),c=(r.top+r.height/2-innerHeight/2)/innerHeight;c=Math.max(-1,Math.min(1,c));cs.forEach(function(el,i){el.style.setProperty('--py',(c*(i%2?-1:1)*(10+i*5)).toFixed(1)+'px')})}
addEventListener('scroll',function(){if(!raf)raf=requestAnimationFrame(par)},{passive:true});par()}});
})();
(function(){
var rm=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(pointer:fine)').matches,desk=function(){return matchMedia('(min-width:768px)').matches};
[].slice.call(document.querySelectorAll('[data-mo=explorer]')).forEach(function(root){
var tabs=[].slice.call(root.querySelectorAll('.ex-tab')),panels=[].slice.call(root.querySelectorAll('.ex-panel')),pills=[].slice.call(root.querySelectorAll('.ex-pill')),stage=root.querySelector('.ex-stage'),n=tabs.length,cur=0,manual=false,NS='http://www.w3.org/2000/svg';
if(!n)return;
root.classList.add('js-ex');document.documentElement.classList.add('js-ex');
root.style.setProperty('--ex-ms',(+root.getAttribute('data-ms')||7000)+'ms');
root.querySelector('.ex-rail ol').setAttribute('role','tablist');root.querySelector('.ex-rail ol').setAttribute('aria-orientation','vertical');
[].slice.call(root.querySelectorAll('.ex-rail li')).forEach(function(li){li.setAttribute('role','presentation')});
tabs.forEach(function(t,i){t.setAttribute('role','tab');t.removeAttribute('aria-current');t.setAttribute('aria-selected',i===0?'true':'false');t.tabIndex=i===0?0:-1;t.setAttribute('href',t.getAttribute('href'))});
panels.forEach(function(p,i){p.setAttribute('role','tabpanel');p.removeAttribute('aria-roledescription');p.hidden=false;if(i===0)p.classList.add('is-on')});
function drawConn(p){if(!desk()){return}var old=p.querySelector('.ex-conn');if(old)old.remove();var plate=p.querySelector('.ex-plate'),chips=[].slice.call(p.querySelectorAll('.ex-chip'));if(!plate||!chips.length)return;
var pr=p.getBoundingClientRect(),cr=plate.querySelector('.ex-card').getBoundingClientRect(),svg=document.createElementNS(NS,'svg');svg.setAttribute('class','ex-conn');svg.setAttribute('aria-hidden','true');svg.setAttribute('viewBox','0 0 '+pr.width+' '+pr.height);
var tx=cr.left-pr.left+cr.width*.1,ty0=cr.top-pr.top+cr.height*.5,ty1=cr.top-pr.top+cr.height*.85;
chips.forEach(function(c,i){var r=c.getBoundingClientRect(),x=r.right-pr.left,y=r.top-pr.top+r.height/2,ty=ty0+(chips.length>1?(ty1-ty0)*i/(chips.length-1):0),mx=x+(tx-x)*.5;
var d=document.createElementNS(NS,'path');d.setAttribute('d','M'+x+' '+y+' C'+mx+' '+y+' '+mx+' '+ty+' '+tx+' '+ty);svg.appendChild(d);var o=document.createElementNS(NS,'circle');o.setAttribute('cx',tx);o.setAttribute('cy',ty);o.setAttribute('r',4.5);svg.appendChild(o)});
p.insertBefore(svg,p.firstChild)}
function drawAll(){drawConn(panels[cur])}
function restartRing(){var r=tabs[cur].querySelector('.ex-ring-fg');if(!r)return;r.style.animation='none';void r.getBoundingClientRect();r.style.animation=''}
function show(i,user){if(i===cur&&!user)return;var dir=i>cur?1:-1;if(i===0&&cur===n-1&&!user)dir=1;if(i===n-1&&cur===0&&!user)dir=-1;root.style.setProperty('--exd',dir);
var old=panels[cur];old.classList.remove('is-on');old.classList.add('is-out');setTimeout(function(){old.classList.remove('is-out')},760);
tabs.forEach(function(t,j){t.setAttribute('aria-selected',j===i?'true':'false');t.tabIndex=j===i?0:-1});
cur=i;panels[i].classList.add('is-on');pills.forEach(function(p){p.classList.toggle('is-here',+p.getAttribute('data-i')===i)});
requestAnimationFrame(function(){drawAll()});restartRing()}
function manualSel(i,focus){if(!manual){manual=true;root.classList.add('is-manual')}show(i,true);if(focus)tabs[i].focus()}
tabs.forEach(function(t,i){t.addEventListener('click',function(e){e.preventDefault();manualSel(i,false)});
t.addEventListener('keydown',function(e){var k=e.key,j=-1;if(k==='ArrowDown'||k==='ArrowRight')j=(i+1)%n;else if(k==='ArrowUp'||k==='ArrowLeft')j=(i-1+n)%n;else if(k==='Home')j=0;else if(k==='End')j=n-1;if(j<0)return;e.preventDefault();manualSel(j,true)})});
pills.forEach(function(p){p.setAttribute('role','button');p.addEventListener('click',function(e){e.preventDefault();manualSel(+p.getAttribute('data-i'),false)})});
pills[0]&&pills[0].classList.add('is-here');
/* tilt + parallax */
if(!rm&&fine){stage.addEventListener('pointermove',function(e){if(!desk())return;var p=panels[cur],card=p.querySelector('.ex-card');if(!card)return;var r=stage.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;card.style.setProperty('--ry',(x*14).toFixed(2)+'deg');card.style.setProperty('--rx',(-y*10).toFixed(2)+'deg');card.style.setProperty('--sx',(50+x*60).toFixed(0)+'%');var g=p.querySelector('.ex-glow');if(g)g.style.transform='translate('+(x*-26).toFixed(1)+'px,'+(y*-18).toFixed(1)+'px)'});
stage.addEventListener('pointerleave',function(){panels.forEach(function(p){var c=p.querySelector('.ex-card');if(c){c.style.setProperty('--rx','0deg');c.style.setProperty('--ry','0deg')}})})}
/* autoplay */
if(!rm){var vis=false;
var io='IntersectionObserver' in window?new IntersectionObserver(function(es){es.forEach(function(e){vis=e.isIntersecting;root.classList.toggle('is-live',vis);if(vis&&!manual)restartRing()})},{threshold:.35}):null;
if(io)io.observe(root);else root.classList.add('is-live');
var holds=0;function hold(a){holds=Math.max(0,holds+(a?1:-1));root.classList.toggle('is-paused',holds>0)}
var hov=false,foc=false;
root.addEventListener('pointerenter',function(e){if(e.pointerType!=='touch'&&!hov){hov=true;hold(true)}});root.addEventListener('pointerleave',function(){if(hov){hov=false;hold(false)}});
root.addEventListener('focusin',function(){if(!foc){foc=true;hold(true)}});root.addEventListener('focusout',function(e){if(foc&&!root.contains(e.relatedTarget)){foc=false;hold(false)}});
root.addEventListener('pointerdown',function(e){if(e.pointerType==='touch'&&!manual){manual=true;root.classList.add('is-manual')}});
root.addEventListener('animationend',function(e){if(e.animationName==='exring'&&!manual)show((cur+1)%n,false)})}
var rt;addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(drawAll,120)});
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(drawAll);
addEventListener('load',drawAll);requestAnimationFrame(drawAll)});
})();

(function(){
if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
var desk=function(){return matchMedia('(min-width:768px)').matches};
function clamp(x){return x<0?0:x>1?1:x}
[].slice.call(document.querySelectorAll('[data-mo=journey]')).forEach(function(root){
var steps=[].slice.call(root.querySelectorAll('.jy-step')),n=steps.length;if(n<2)return;
var stage=root.querySelector('.jy-stage'),path=root.querySelector('.jy-path'),list=root.querySelector('.jy-steps'),btns=steps.map(function(s){return s.querySelector('.jy-node')});
root.classList.add('js-jy');root.style.setProperty('--n',n);
/* panel + replay */
var panel=document.createElement('div');panel.className='jy-panel';panel.id=root.id+'-panel';panel.setAttribute('role','region');panel.setAttribute('aria-live','off');panel.setAttribute('aria-label','Selected step');
var panes=steps.map(function(s,i){var pn=document.createElement('div');pn.className='jy-pane';pn.setAttribute('aria-hidden',i?'true':'false');
pn.innerHTML='<span class="jy-big" aria-hidden="true">0'+(i+1)+'</span><div class="jy-pc"><p class="jy-k"><span>0'+(i+1)+'</span>'+(s.getAttribute('data-when')||'')+'</p>'+s.querySelector('.jy-detail').innerHTML+'</div>';panel.appendChild(pn);return pn});
var bar=document.createElement('div');bar.className='jy-bar';
bar.innerHTML='<button type="button" class="jy-replay"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.500 12a8.500 8.500 0 1 0 2.600-6.100M3.500 4v4.500H8"/></svg>Replay</button>';
stage.insertBefore(bar,path);path.appendChild(panel);
var rb=bar.firstChild,P=0,cur=-1,mode='auto',started=false,t0=0,raf=0,tw=null,curSel=0;
function paint(i){if(i===cur)return;cur=i;panes.forEach(function(p,j){p.classList.toggle('is-on',j===i);p.setAttribute('aria-hidden',j===i?'false':'true')});
btns.forEach(function(b,j){if(j===i)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current')})}
function renderDesk(){path.style.setProperty('--p',P.toFixed(4));root.style.setProperty('--p',P.toFixed(4));root.setAttribute('data-p',P.toFixed(3));var c=0;
steps.forEach(function(s,i){var r=P>=i/(n-1)-.025;if(r)c=i;s.classList.toggle('is-lit',r)});if(mode==='manual')c=curSel;steps.forEach(function(s,i){s.classList.toggle('is-cur',i===c)});paint(c)}
function renderMob(){var vy=innerHeight*.62,r=list.getBoundingClientRect(),fy=Math.max(0,Math.min(r.height,vy-r.top)),c=0;
var first=btns[0].getBoundingClientRect(),lastB=btns[n-1].getBoundingClientRect(),lr=path.querySelector('.jy-line').getBoundingClientRect();
path.style.setProperty('--fy',Math.max(0,Math.min(lr.height,vy-lr.top)).toFixed(0)+'px');
steps.forEach(function(s,i){var b=btns[i].getBoundingClientRect(),r2=b.top+b.height/2<=vy;if(r2)c=i;s.classList.toggle('is-lit',r2)});steps.forEach(function(s,i){s.classList.toggle('is-cur',i===c)});paint(c);root.setAttribute('data-p',(lr.height?Math.max(0,Math.min(lr.height,vy-lr.top))/lr.height:0).toFixed(3))}
function scrollP(){var r=stage.getBoundingClientRect();return clamp((innerHeight*.85-r.top)/(innerHeight*.55))}
var SEG=700,DW=800;
function autoP(t){var k=SEG+DW,s=Math.min(n-2,Math.floor(t/k)),u=t-s*k,f=clamp(u/SEG);f=f<.5?2*f*f:1-Math.pow(-2*f+2,2)/2;if(t>=(n-1)*k-DW)return 1;return (s+f)/(n-1)}
function ease(f){return f<.5?2*f*f:1-Math.pow(-2*f+2,2)/2}
function frame(ts){raf=0;var go=false;
if(tw){var f=clamp((ts-tw.t)/tw.d);P=tw.a+(tw.b-tw.a)*ease(f);if(f<1)go=true;else{P=tw.b;tw=null}}
else if(mode==='auto'||mode==='replay'){var a=autoP(ts-t0);P=mode==='auto'?Math.max(P,a,scrollP()):a;if(ts-t0<(n-1)*(SEG+DW)-DW)go=true;else{P=1;mode='done'}}
renderDesk();if(go)raf=requestAnimationFrame(frame)}
function kick(){if(!raf)raf=requestAnimationFrame(frame)}
function select(i,focus){i=Math.max(0,Math.min(n-1,i));if(mode==='manual'&&curSel===i&&(!tw||tw.i===i)){if(focus)btns[i].focus();return}mode='manual';curSel=i;panel.setAttribute('aria-live','polite');
var b=i/(n-1);tw={i:i,a:P,b:b,d:Math.max(450,Math.abs(b-P)*(n-1)*300),t:performance.now()};if(focus)btns[i].focus();kick()}
btns.forEach(function(b,i){b.addEventListener('click',function(){if(desk())select(i,false)});b.addEventListener('focus',function(){if(desk()&&!tw&&(mode!=='manual'||curSel!==i))select(i,false)})});
root.addEventListener('keydown',function(e){if(!desk()||!stage.contains(e.target)||e.target===rb)return;var k=e.key,i=cur<0?0:(mode==='manual'?curSel:cur);
if(k==='ArrowRight'||k==='ArrowDown')i++;else if(k==='ArrowLeft'||k==='ArrowUp')i--;else if(k==='Home')i=0;else if(k==='End')i=n-1;else return;e.preventDefault();select(i,true)});
rb.addEventListener('click',function(){tw=null;mode='replay';P=0;curSel=0;panel.setAttribute('aria-live','off');t0=performance.now();renderDesk();kick()});
function tick(){raf2=0;if(desk()){if(mode==='auto'){var sp=scrollP();if(sp>P){P=sp;renderDesk()}}else if(!raf)renderDesk()}else renderMob()}
var raf2=0;function onScroll(){if(!raf2)raf2=requestAnimationFrame(tick)}
addEventListener('scroll',onScroll,{passive:true});addEventListener('resize',onScroll);
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(onScroll);
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting&&!started&&desk()){started=true;if(mode==='auto'){t0=performance.now();kick()}}})},{threshold:.3});io.observe(stage)}
else if(desk()){started=true;t0=performance.now();kick()}
(desk()?renderDesk:renderMob)();onScroll();
});
})();